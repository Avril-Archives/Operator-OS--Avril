# FastAPI Python Backend Configuration

## Project Context

<context>
This is a FastAPI microservice built with Python 3.11+, emphasizing async operations and type safety. The project focuses on:

- **Async-first architecture** using Python's native async/await patterns
- **Type safety** with Python type hints and Pydantic v2 models
- **Auto-generated documentation** with OpenAPI/Swagger at `/docs` and ReDoc at `/redoc`
- **Database access** via SQLAlchemy (async) or asyncpg for PostgreSQL
- **Clean code** following Ruff linting standards and Black formatting
- **Fast development** with automatic reload and interactive API docs

FastAPI combines the simplicity of Flask with the performance of async frameworks, making it ideal for high-throughput microservices with clear API contracts.
</context>

## Technical Stack

<stack>
- **Python:** ≥ 3.11 with type hints everywhere
- **Framework:** FastAPI with Pydantic v2 models
- **Database:** PostgreSQL with SQLAlchemy (async) or asyncpg
- **Validation:** Pydantic models for request/response schemas
- **Linting:** Ruff (fast Python linter)
- **Formatting:** Black (opinionated formatter)
- **Testing:** Pytest with pytest-asyncio
- **Logging:** structlog for structured logging
- **Encoding:** UTF-8 with LF line endings, 4-space indentation (PEP 8)
</stack>

## Project Structure

<structure>
```
/app
 ├─ main.py                   # FastAPI app instance
 ├─ /routes                   # API route modules
 │   ├─ users.py
 │   ├─ auth.py
 │   └─ health.py
 ├─ /models                   # Pydantic schemas & SQLAlchemy models
 │   ├─ user.py               # Pydantic schemas
 │   ├─ database.py           # SQLAlchemy models
 │   └─ schemas.py            # Shared schemas
 ├─ /services                 # Business logic layer
 │   ├─ user_service.py
 │   └─ auth_service.py
 ├─ /core                     # Core configuration
 │   ├─ config.py             # Pydantic Settings
 │   ├─ dependencies.py       # FastAPI dependencies
 │   └─ security.py           # Auth utilities
 ├─ /utils                    # Helper functions
 │   ├─ formatters.py
 │   ├─ validators.py
 │   └─ logger.py

/tests                        # Pytest test files
 ├─ /unit
 └─ /integration

/docs                         # Additional documentation
/alembic                      # Database migrations
 ├─ versions/
 └─ env.py
```
</structure>

## Working with Routes and Models

<conventions>
When creating or modifying API endpoints, follow these patterns:

### Route Modules with APIRouter

**Organize routes by domain** using FastAPI's `APIRouter` for modularity.

**Example: User Routes**
```python
# routes/users.py
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.user import UserCreate, UserResponse, UserUpdate
from app.services import user_service
from app.core.dependencies import get_db, get_current_user

router = APIRouter(prefix="/users", tags=["users"])


@router.post(
    "/",
    response_model=UserResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create a new user",
    description="Register a new user with email and password"
)
async def create_user(
    user_data: UserCreate,
    db: AsyncSession = Depends(get_db)
) -> UserResponse:
    """
    Create a new user account.

    - **email**: Valid email address (unique)
    - **password**: Minimum 8 characters
    - **name**: User's full name
    """
    existing = await user_service.get_by_email(db, user_data.email)
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already registered"
        )

    user = await user_service.create(db, user_data)
    return user


@router.get(
    "/{user_id}",
    response_model=UserResponse,
    summary="Get user by ID"
)
async def get_user(
    user_id: int,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
) -> UserResponse:
    """Retrieve a user by their ID."""
    user = await user_service.get_by_id(db, user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    return user


@router.patch(
    "/{user_id}",
    response_model=UserResponse,
    summary="Update user"
)
async def update_user(
    user_id: int,
    user_data: UserUpdate,
    db: AsyncSession = Depends(get_db),
    current_user = Depends(get_current_user)
) -> UserResponse:
    """Update user information."""
    # Authorization check
    if current_user.id != user_id and not current_user.is_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to update this user"
        )

    user = await user_service.update(db, user_id, user_data)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    return user
```

### Pydantic Models for Validation

**Define clear schemas** for requests and responses using Pydantic v2.

**Example: User Schemas**
```python
# models/user.py
from pydantic import BaseModel, EmailStr, Field, ConfigDict
from datetime import datetime


class UserBase(BaseModel):
    """Base user schema with common fields."""
    email: EmailStr
    name: str = Field(min_length=2, max_length=100)


class UserCreate(UserBase):
    """Schema for creating a new user."""
    password: str = Field(
        min_length=8,
        max_length=100,
        description="Password must be at least 8 characters"
    )


class UserUpdate(BaseModel):
    """Schema for updating user (all fields optional)."""
    email: EmailStr | None = None
    name: str | None = Field(None, min_length=2, max_length=100)
    password: str | None = Field(None, min_length=8)


class UserResponse(UserBase):
    """Schema for user responses (excludes password)."""
    id: int
    is_active: bool
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


class UserInDB(UserResponse):
    """Internal schema including sensitive fields."""
    hashed_password: str
```

### Service Layer for Business Logic

**Keep route handlers thin** by delegating to service functions.

**Example: User Service**
```python
# services/user_service.py
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.models.user import UserCreate, UserUpdate
from app.models.database import User
from app.core.security import get_password_hash, verify_password
import logging

logger = logging.getLogger(__name__)


async def create(db: AsyncSession, user_data: UserCreate) -> User:
    """Create a new user with hashed password."""
    hashed_password = get_password_hash(user_data.password)

    db_user = User(
        email=user_data.email,
        name=user_data.name,
        hashed_password=hashed_password
    )

    db.add(db_user)
    await db.commit()
    await db.refresh(db_user)

    logger.info(f"User created: {db_user.id}")
    return db_user


async def get_by_id(db: AsyncSession, user_id: int) -> User | None:
    """Retrieve user by ID."""
    result = await db.execute(
        select(User).where(User.id == user_id)
    )
    return result.scalar_one_or_none()


async def get_by_email(db: AsyncSession, email: str) -> User | None:
    """Retrieve user by email."""
    result = await db.execute(
        select(User).where(User.email == email)
    )
    return result.scalar_one_or_none()


async def update(
    db: AsyncSession,
    user_id: int,
    user_data: UserUpdate
) -> User | None:
    """Update user information."""
    user = await get_by_id(db, user_id)
    if not user:
        return None

    # Update only provided fields
    update_data = user_data.model_dump(exclude_unset=True)

    if "password" in update_data:
        update_data["hashed_password"] = get_password_hash(
            update_data.pop("password")
        )

    for field, value in update_data.items():
        setattr(user, field, value)

    await db.commit()
    await db.refresh(user)

    logger.info(f"User updated: {user_id}")
    return user


async def authenticate(
    db: AsyncSession,
    email: str,
    password: str
) -> User | None:
    """Authenticate user by email and password."""
    user = await get_by_email(db, email)
    if not user:
        return None

    if not verify_password(password, user.hashed_password):
        return None

    return user
```

### Database Models (SQLAlchemy)

**Define database schema** using SQLAlchemy async models.

**Example: User Model**
```python
# models/database.py
from sqlalchemy import Boolean, Column, Integer, String, DateTime
from sqlalchemy.sql import func
from app.core.database import Base


class User(Base):
    """User database model."""
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    name = Column(String, nullable=False)
    hashed_password = Column(String, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    is_admin = Column(Boolean, default=False, nullable=False)

    created_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False
    )
    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False
    )

    def __repr__(self):
        return f"<User(id={self.id}, email={self.email})>"
```

### Dependency Injection

**Use FastAPI's dependency system** for database sessions, authentication, etc.

**Example: Dependencies**
```python
# core/dependencies.py
from typing import AsyncGenerator
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import AsyncSessionLocal
from app.core.security import decode_token
from app.services import user_service

security = HTTPBearer()


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """Dependency for database sessions."""
    async with AsyncSessionLocal() as session:
        try:
            yield session
        finally:
            await session.close()


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """Dependency for authenticated requests."""
    token = credentials.credentials

    try:
        payload = decode_token(token)
        user_id = payload.get("sub")
        if user_id is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token"
            )
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials"
        )

    user = await user_service.get_by_id(db, int(user_id))
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found"
        )

    return user
```

### Health Check Endpoint

**Include a health check** for monitoring.

```python
# routes/health.py
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from datetime import datetime

from app.core.dependencies import get_db

router = APIRouter(tags=["health"])


@router.get("/health")
async def health_check(db: AsyncSession = Depends(get_db)):
    """
    Health check endpoint.

    Returns service status and database connectivity.
    """
    try:
        # Test database connection
        await db.execute(text("SELECT 1"))

        return {
            "status": "ok",
            "timestamp": datetime.utcnow().isoformat(),
            "database": "connected"
        }
    except Exception as e:
        return {
            "status": "error",
            "timestamp": datetime.utcnow().isoformat(),
            "database": "disconnected",
            "error": str(e)
        }
```

### Application Setup

**Configure FastAPI application** with middleware and routers.

**Example: Main Application**
```python
# main.py
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware

from app.routes import users, auth, health
from app.core.config import settings

app = FastAPI(
    title=settings.PROJECT_NAME,
    description="FastAPI microservice with async patterns",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Gzip compression
app.add_middleware(GZipMiddleware, minimum_size=1000)

# Include routers
app.include_router(health.router)
app.include_router(users.router, prefix="/api/v1")
app.include_router(auth.router, prefix="/api/v1")


@app.on_event("startup")
async def startup():
    """Initialize application."""
    print(f"Starting {settings.PROJECT_NAME}...")


@app.on_event("shutdown")
async def shutdown():
    """Cleanup on shutdown."""
    print("Shutting down...")
```

### Configuration with Pydantic Settings

**Use Pydantic Settings** for type-safe environment configuration.

```python
# core/config.py
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import List


class Settings(BaseSettings):
    """Application settings loaded from environment."""

    # Project
    PROJECT_NAME: str = "FastAPI Service"
    API_V1_PREFIX: str = "/api/v1"

    # Database
    DATABASE_URL: str

    # Security
    SECRET_KEY: str
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30

    # CORS
    ALLOWED_ORIGINS: List[str] = ["http://localhost:5173"]

    # Logging
    LOG_LEVEL: str = "INFO"

    model_config = SettingsConfigDict(
        env_file=".env",
        case_sensitive=True
    )


settings = Settings()
```
</conventions>

## Development Workflow

<development>
### Starting the Development Server

```bash
# Install dependencies
pip install -r requirements.txt

# Start with auto-reload
uvicorn app.main:app --reload --port 8000
```

The API will be available at:
- **API:** `http://localhost:8000`
- **Swagger Docs:** `http://localhost:8000/docs`
- **ReDoc:** `http://localhost:8000/redoc`

### Database Migrations

```bash
# Create a new migration
alembic revision --autogenerate -m "Description"

# Apply migrations
alembic upgrade head

# Rollback one migration
alembic downgrade -1
```

### When Making Changes

1. **Define Pydantic models first** — This ensures contracts are clear
2. **Write service functions** — Business logic goes here
3. **Create route handlers** — Thin wrappers around services
4. **Add tests** — Both unit and integration tests
5. **Update OpenAPI descriptions** — Keep docs current
</development>

## Code Quality & Validation

<validation>
Run these commands before committing:

```bash
# Linting
ruff check .

# Auto-fix linting issues
ruff check . --fix

# Formatting
black .

# Type checking
mypy app

# Run tests
pytest

# Test coverage
pytest --cov=app

# Run all checks
ruff check . && black . && mypy app && pytest
```

**Quality Gates:**
- All tests pass
- No Ruff linting errors
- Black formatting applied
- Type hints pass mypy checks
- Test coverage ≥ 80%
</validation>

## Making Edits

<guidance>
When I work on this codebase, I will:

### Maintain Async Patterns

- **Use `async def`** for all route handlers and service functions
- **Await database calls** — Never block the event loop
- **Use async context managers** — `async with` for sessions
- **Don't mix sync and async** — Keep patterns consistent

**Example: Async Best Practices**
```python
# ✅ Good: Fully async
async def get_users(db: AsyncSession, skip: int = 0, limit: int = 100):
    result = await db.execute(
        select(User).offset(skip).limit(limit)
    )
    return result.scalars().all()

# ❌ Bad: Blocking call in async function
async def bad_get_users(db: AsyncSession):
    time.sleep(1)  # Blocks event loop!
    return db.query(User).all()  # Not awaited!
```

### Dependency Injection

Use FastAPI's dependency system for:
- Database sessions
- Authentication
- Configuration
- Shared utilities

**Example: Custom Dependency**
```python
from fastapi import Depends, Query

async def pagination_params(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000)
):
    """Reusable pagination parameters."""
    return {"skip": skip, "limit": limit}

@router.get("/users")
async def list_users(
    db: AsyncSession = Depends(get_db),
    pagination: dict = Depends(pagination_params)
):
    users = await user_service.list_users(
        db,
        skip=pagination["skip"],
        limit=pagination["limit"]
    )
    return users
```

### Error Handling

Use HTTPException with appropriate status codes and messages.

```python
from fastapi import HTTPException, status

# ✅ Good: Clear error with proper status
raise HTTPException(
    status_code=status.HTTP_404_NOT_FOUND,
    detail="User not found"
)

# ✅ Good: Detailed error information
raise HTTPException(
    status_code=status.HTTP_400_BAD_REQUEST,
    detail={
        "message": "Validation failed",
        "errors": ["Email is required", "Password too short"]
    }
)
```
</guidance>

## Deployment

<deployment>
### Building for Production

```bash
# Run with production server (multiple workers)
uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 4
```

### Environment Variables

Required `.env` file:

```env
PROJECT_NAME=FastAPI Service
DATABASE_URL=postgresql+asyncpg://user:pass@host:5432/dbname
SECRET_KEY=your-secret-key-here
ALLOWED_ORIGINS=https://yourapp.com,https://www.yourapp.com
LOG_LEVEL=INFO
```

### Deployment Checklist

✅ Environment variables configured
✅ Database migrations applied
✅ Health check endpoint responding
✅ CORS configured for production
✅ Async connection pooling configured
✅ Logging set to appropriate level
✅ Error tracking enabled (Sentry, etc.)

### Coolify Deployment

- **Start Command:** `uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 4`
- **Port:** `8000`
- **Health Check:** `GET /health` should return 200
- **Build:** Use Dockerfile or Nixpacks
</deployment>

## Version Control

<git>
### Branch Strategy

- `main` — Production-ready code
- `feature/*` — New features
- `fix/*` — Bug fixes
- `docs/*` — Documentation updates

### Commit Conventions

**Good commits:**
- `Add user registration endpoint with email validation`
- `Fix async database session handling`
- `Update Pydantic models for v2 compatibility`
- `Refactor auth service for better token handling`

**Before merging:**
- ✅ All tests pass
- ✅ Ruff linting passes
- ✅ Black formatting applied
- ✅ Type checking passes (mypy)
- ✅ API documentation updated
</git>

## Design Philosophy

<philosophy>
**Typed, async, and documented by design.**

FastAPI's strength is automatic documentation generation from type hints. Every Pydantic model, every route signature contributes to the OpenAPI spec at `/docs`.

**Pydantic-driven validation, auto-generated docs, production-ready always.**

Type hints aren't just documentation—they're runtime validation. Pydantic models ensure data integrity at API boundaries.

**Fast by default, secure through types, scalable through async patterns.**

Async/await enables high concurrency without threads. Database queries, HTTP requests, file I/O—all non-blocking by default.
</philosophy>

---

**When in doubt, let Pydantic validate.** Define clear models for every data structure. The type system is your friend—use it liberally and let FastAPI handle the rest.
