# Full-Stack Application Configuration

## Project Context

<context>
This is a full-stack application integrating frontend and backend with a unified design system and shared conventions. The project emphasizes:

- **Cohesive architecture** with frontend and backend working as a unified system
- **Shared design tokens** from `/shared/tokens.json` used across all UI layers
- **Consistent conventions** for code style, validation patterns, and error handling
- **Type-safe contracts** between frontend and backend (shared TypeScript types)
- **Mobile-first design** with OKLCH color tokens and responsive layouts (320–1440px)
- **Production-ready deployment** with Docker Compose for local development

The architecture treats frontend and backend as complementary parts of a single application, sharing context through design tokens, TypeScript types, and API conventions.
</context>

## Technical Stack

<stack>
**Frontend:**
- React + Vite OR Static HTML/CSS/JS
- OKLCH tokens from `/shared/tokens.json`
- Inter + JetBrains Mono fonts
- Phosphor Icons

**Backend:**
- Node.js + Express/Fastify OR
- FastAPI (Python) OR
- PHP (Laravel/Symfony)
- PostgreSQL with typed ORM
- Structured logging and validation

**Shared:**
- Mobile-first design (320–1440px)
- No flex-wrap anywhere
- UTF-8 encoding, LF endings, 2-space indent (JS/CSS), 4-space (Python/PHP)
- Monochrome palette with purposeful color signals
- 4px base spacing scale
</stack>

## Project Structure

<structure>
```
/project
 ├─ /frontend                 # Frontend application
 │   ├─ /src
 │   │   ├─ /components       # React components OR
 │   │   ├─ /pages            # Page components
 │   │   ├─ /hooks            # Custom hooks
 │   │   ├─ /styles           # CSS with tokens
 │   │   ├─ /utils            # Frontend utilities
 │   │   │   └─ api-client.ts # Typed API client
 │   │   └─ App.jsx
 │   ├─ /public
 │   └─ package.json
 │
 ├─ /frontend-static          # OR Static frontend
 │   ├─ index.html
 │   ├─ /scripts
 │   ├─ /styles
 │   └─ /assets
 │
 ├─ /backend                  # Backend application
 │   ├─ /src OR /app
 │   │   ├─ /routes           # API endpoints
 │   │   ├─ /controllers      # Request handlers
 │   │   ├─ /services         # Business logic
 │   │   ├─ /models           # Database models
 │   │   ├─ /middlewares      # Middleware
 │   │   └─ server.ts
 │   ├─ /tests
 │   └─ package.json
 │
 ├─ /shared                   # Shared resources
 │   ├─ tokens.json           # Design system (OKLCH colors, spacing, typography)
 │   ├─ /types                # Shared TypeScript interfaces
 │   │   ├─ user.ts
 │   │   ├─ api.ts
 │   │   └─ index.ts
 │   └─ /constants            # Shared constants
 │       └─ api-endpoints.ts
 │
 ├─ /docs                     # Documentation
 │   ├─ architecture.md
 │   ├─ api-spec.yaml         # OpenAPI specification
 │   └─ deployment.md
 │
 ├─ /scripts                  # Automation scripts
 │   ├─ deploy.sh
 │   └─ migrate.sh
 │
 ├─ docker-compose.yml        # Local development setup
 ├─ .env.example              # Environment template
 └─ README.md
```
</structure>

## Working with Shared Resources

<shared-conventions>
### Design Token System

**All UI derives from `/shared/tokens.json`**. This ensures visual consistency across frontend, backend templates, emails, and documentation.

**Example: tokens.json**
```json
{
  "colors": {
    "primary": "oklch(0.5 0.2 220)",
    "surface": "oklch(0.95 0.01 220)",
    "text": "oklch(0.2 0.01 220)",
    "text-muted": "oklch(0.5 0.01 220)",
    "border": "oklch(0.85 0.01 220)",
    "success": "oklch(0.6 0.15 145)",
    "warning": "oklch(0.7 0.15 85)",
    "error": "oklch(0.6 0.2 25)"
  },
  "spacing": {
    "xs": "4px",
    "sm": "8px",
    "md": "16px",
    "lg": "24px",
    "xl": "32px",
    "2xl": "48px",
    "3xl": "64px"
  },
  "typography": {
    "font-family-base": "Inter, system-ui, sans-serif",
    "font-family-mono": "JetBrains Mono, Consolas, monospace",
    "font-size-xs": "12px",
    "font-size-sm": "14px",
    "font-size-base": "16px",
    "font-size-lg": "18px",
    "font-size-xl": "24px",
    "font-size-2xl": "32px",
    "line-height-tight": "1.25",
    "line-height-base": "1.5",
    "line-height-relaxed": "1.75"
  },
  "layout": {
    "max-width-content": "1440px",
    "max-width-text": "65ch",
    "grid-columns": 24
  }
}
```

**Using in Frontend CSS:**
```css
/* frontend/src/styles/tokens.css */
:root {
  --color-primary: oklch(0.5 0.2 220);
  --color-surface: oklch(0.95 0.01 220);
  --spacing-md: 16px;
  --font-family-base: Inter, system-ui, sans-serif;
}

.button {
  background: var(--color-primary);
  padding: var(--spacing-md);
  font-family: var(--font-family-base);
}
```

**Using in Backend Templates:**
```html
<!-- Backend template with same tokens -->
<style>
:root {
  --color-primary: oklch(0.5 0.2 220);
  --spacing-md: 16px;
}
</style>

<button style="background: var(--color-primary); padding: var(--spacing-md);">
  Submit
</button>
```

### Shared TypeScript Types

**Define API contracts once** in `/shared/types` and import in both frontend and backend.

**Example: User Types**
```typescript
// shared/types/user.ts
export interface User {
  id: number;
  email: string;
  name: string;
  createdAt: string;
  updatedAt: string;
}

export interface CreateUserInput {
  email: string;
  name: string;
  password: string;
}

export interface UpdateUserInput {
  email?: string;
  name?: string;
  password?: string;
}

export interface UserResponse {
  success: boolean;
  data?: User;
  error?: string;
}

export interface UsersListResponse {
  success: boolean;
  data?: User[];
  pagination?: {
    page: number;
    limit: number;
    total: number;
    pages: number;
  };
  error?: string;
}
```

**Using in Backend:**
```typescript
// backend/src/controllers/user.controller.ts
import { CreateUserInput, UserResponse } from '@shared/types/user';

export async function createUser(req: Request, res: Response) {
  const userData: CreateUserInput = req.body;

  const user = await userService.create(userData);

  const response: UserResponse = {
    success: true,
    data: user
  };

  res.status(201).json(response);
}
```

**Using in Frontend:**
```typescript
// frontend/src/utils/api-client.ts
import { CreateUserInput, UserResponse } from '@shared/types/user';

export async function createUser(
  data: CreateUserInput
): Promise<UserResponse> {
  const response = await fetch('/api/users', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });

  return await response.json();
}
```

### Shared API Constants

**Centralize API endpoint definitions** to avoid magic strings.

```typescript
// shared/constants/api-endpoints.ts
export const API_BASE = '/api/v1';

export const ENDPOINTS = {
  // Auth
  LOGIN: `${API_BASE}/auth/login`,
  LOGOUT: `${API_BASE}/auth/logout`,
  REGISTER: `${API_BASE}/auth/register`,

  // Users
  USERS: `${API_BASE}/users`,
  USER_BY_ID: (id: number) => `${API_BASE}/users/${id}`,

  // Posts
  POSTS: `${API_BASE}/posts`,
  POST_BY_ID: (id: number) => `${API_BASE}/posts/${id}`,

  // Health
  HEALTH: '/health'
} as const;
```

**Usage:**
```typescript
// Frontend
import { ENDPOINTS } from '@shared/constants/api-endpoints';

const response = await fetch(ENDPOINTS.USERS);

// Backend
import { ENDPOINTS } from '@shared/constants/api-endpoints';

router.get(ENDPOINTS.USERS, getAllUsers);
```
</shared-conventions>

## Frontend Conventions

<frontend-conventions>
When working on the frontend, follow these patterns:

### Component Structure

- **Small, focused components** with single responsibility
- **Co-located styles** using CSS modules or scoped styles
- **Token-first design** — Never hardcode colors or spacing
- **Accessibility mandatory** — ARIA labels, keyboard navigation
- **Lazy loading** for routes and heavy components

**Example: Frontend Component**
```tsx
// frontend/src/components/UserCard.tsx
import { User } from '@shared/types/user';
import './UserCard.css';

interface UserCardProps {
  user: User;
  onEdit?: (user: User) => void;
}

export function UserCard({ user, onEdit }: UserCardProps) {
  return (
    <article className="user-card">
      <header className="user-card__header">
        <h3 className="user-card__name">{user.name}</h3>
        <span className="user-card__email">{user.email}</span>
      </header>

      {onEdit && (
        <footer className="user-card__footer">
          <button
            onClick={() => onEdit(user)}
            className="btn btn--secondary"
            aria-label={`Edit ${user.name}`}
          >
            Edit
          </button>
        </footer>
      )}
    </article>
  );
}
```

### API Client with Typed Responses

**Create a typed API client** that uses shared types.

```typescript
// frontend/src/utils/api-client.ts
import { ENDPOINTS } from '@shared/constants/api-endpoints';
import type {
  User,
  CreateUserInput,
  UpdateUserInput,
  UserResponse,
  UsersListResponse
} from '@shared/types/user';

class ApiClient {
  private async request<T>(
    url: string,
    options?: RequestInit
  ): Promise<T> {
    const response = await fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options?.headers
      }
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Request failed');
    }

    return await response.json();
  }

  // Users
  async getUsers(): Promise<UsersListResponse> {
    return this.request<UsersListResponse>(ENDPOINTS.USERS);
  }

  async getUserById(id: number): Promise<UserResponse> {
    return this.request<UserResponse>(ENDPOINTS.USER_BY_ID(id));
  }

  async createUser(data: CreateUserInput): Promise<UserResponse> {
    return this.request<UserResponse>(ENDPOINTS.USERS, {
      method: 'POST',
      body: JSON.stringify(data)
    });
  }

  async updateUser(
    id: number,
    data: UpdateUserInput
  ): Promise<UserResponse> {
    return this.request<UserResponse>(ENDPOINTS.USER_BY_ID(id), {
      method: 'PATCH',
      body: JSON.stringify(data)
    });
  }
}

export const api = new ApiClient();
```
</frontend-conventions>

## Backend Conventions

<backend-conventions>
When working on the backend, follow these patterns:

### Controllers Use Shared Types

**Controllers return responses matching shared type contracts.**

```typescript
// backend/src/controllers/user.controller.ts
import { Request, Response } from 'express';
import { userService } from '../services/user.service';
import { createUserSchema } from '../schemas/user.schema';
import type {
  UserResponse,
  UsersListResponse
} from '@shared/types/user';

export async function getAllUsers(
  req: Request,
  res: Response<UsersListResponse>
) {
  const users = await userService.getAllUsers();

  res.json({
    success: true,
    data: users
  });
}

export async function createUser(
  req: Request,
  res: Response<UserResponse>
) {
  const validated = createUserSchema.parse(req.body);
  const user = await userService.create(validated);

  res.status(201).json({
    success: true,
    data: user
  });
}
```

### Validation Schemas Match Shared Types

**Zod/Pydantic schemas validate against shared type contracts.**

```typescript
// backend/src/schemas/user.schema.ts
import { z } from 'zod';
import type { CreateUserInput } from '@shared/types/user';

export const createUserSchema = z.object({
  email: z.string().email().toLowerCase(),
  name: z.string().min(2).max(100),
  password: z.string().min(8)
}) satisfies z.ZodType<CreateUserInput>;
```

### CORS Configuration

**Configure CORS** to allow frontend origin.

```typescript
// backend/src/app.ts
import cors from 'cors';

app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:5173',
  credentials: true
}));
```
</backend-conventions>

## Development Workflow

<development>
### Local Development with Docker Compose

**docker-compose.yml:**
```yaml
version: '3.8'

services:
  frontend:
    build: ./frontend
    ports:
      - "5173:5173"
    volumes:
      - ./frontend:/app
      - ./shared:/shared
    environment:
      - VITE_API_URL=http://localhost:3000
    command: npm run dev

  backend:
    build: ./backend
    ports:
      - "3000:3000"
    volumes:
      - ./backend:/app
      - ./shared:/shared
    environment:
      - DATABASE_URL=postgresql://user:pass@db:5432/myapp
      - FRONTEND_URL=http://localhost:5173
    depends_on:
      - db
    command: npm run dev

  db:
    image: postgres:15-alpine
    ports:
      - "5432:5432"
    environment:
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=pass
      - POSTGRES_DB=myapp
    volumes:
      - postgres_data:/var/lib/postgresql/data

volumes:
  postgres_data:
```

### Starting Development

```bash
# Start all services
docker-compose up

# Or start individually
cd frontend && npm run dev
cd backend && npm run dev
```

**Access:**
- Frontend: `http://localhost:5173`
- Backend: `http://localhost:3000`
- API Docs: `http://localhost:3000/docs`

### When Making Changes

1. **Update shared types first** if API contract changes
2. **Update backend** — Services, controllers, routes
3. **Update frontend** — Components, API client
4. **Test integration** — Verify frontend-backend communication
5. **Update documentation** — Keep API spec and docs current
</development>

## Code Quality & Validation

<validation>
**Frontend:**
```bash
cd frontend
npm run lint          # ESLint
npm run format        # Prettier
npm run test          # Vitest
npm run build         # Production build
```

**Backend:**
```bash
cd backend
npm run lint          # ESLint
npm run format        # Prettier
npm run test          # Vitest/Jest
npm run type-check    # TypeScript
```

**Integration Tests:**
```bash
npm run test:e2e      # Playwright or Cypress
```

**Quality Gates:**
- All unit tests pass
- Integration tests pass
- No linting errors
- No TypeScript errors
- Frontend builds successfully
- Backend builds successfully
- API documentation is current
</validation>

## Making Edits

<guidance>
When I work on this full-stack codebase, I will:

### Respect Boundaries

- **Check local CLAUDE.md first** — Frontend and backend may have specific configs
- **Maintain design token consistency** — All UI derives from `/shared/tokens.json`
- **Update shared types** when API contracts change
- **Avoid duplication** — Share code via `/shared` directory

### Cross-Stack Changes

When a feature requires both frontend and backend changes:

1. **Update shared types** in `/shared/types`
2. **Backend first** — Implement and test API endpoints
3. **Frontend second** — Consume the new API
4. **Integration test** — Verify full stack works together
5. **Update documentation** — API spec and usage docs

### Example: Adding a New Entity

**1. Define shared types:**
```typescript
// shared/types/post.ts
export interface Post {
  id: number;
  title: string;
  content: string;
  authorId: number;
  createdAt: string;
}

export interface CreatePostInput {
  title: string;
  content: string;
}
```

**2. Backend implementation:**
```typescript
// backend/src/services/post.service.ts
export const postService = {
  async create(data: CreatePostInput): Promise<Post> {
    // Implementation
  }
};

// backend/src/routes/posts.ts
router.post('/', validate(createPostSchema), createPost);
```

**3. Frontend implementation:**
```typescript
// frontend/src/utils/api-client.ts
async createPost(data: CreatePostInput): Promise<PostResponse> {
  return this.request(ENDPOINTS.POSTS, {
    method: 'POST',
    body: JSON.stringify(data)
  });
}

// frontend/src/components/PostForm.tsx
function PostForm() {
  const handleSubmit = async (data: CreatePostInput) => {
    await api.createPost(data);
  };
  // ...
}
```

**4. Update constants:**
```typescript
// shared/constants/api-endpoints.ts
export const ENDPOINTS = {
  // ...existing
  POSTS: `${API_BASE}/posts`,
  POST_BY_ID: (id: number) => `${API_BASE}/posts/${id}`,
};
```
</guidance>

## Deployment

<deployment>
### Frontend Deployment

```bash
cd frontend
npm run build
# Output: /dist directory
```

Deploy to:
- Coolify Static Build Pack
- Vercel, Netlify, or similar

### Backend Deployment

```bash
cd backend
npm run build
npm start
```

Deploy to:
- Coolify (Nixpacks or Dockerfile)
- Heroku, Railway, or similar

### Environment Variables

**Frontend (.env):**
```env
VITE_API_URL=https://api.yourapp.com
```

**Backend (.env):**
```env
NODE_ENV=production
PORT=3000
DATABASE_URL=postgresql://...
FRONTEND_URL=https://yourapp.com
CORS_ORIGINS=https://yourapp.com,https://www.yourapp.com
```

### Deployment Checklist

✅ Shared types built and available to both frontend/backend
✅ Frontend environment variables point to production API
✅ Backend CORS configured for production frontend URL
✅ Database migrations applied
✅ Health checks responding
✅ SSL certificates configured
✅ CDN configured for static assets
✅ Monitoring and error tracking enabled
</deployment>

## Version Control

<git>
### Branch Strategy

- `main` — Production-ready code
- `feature/*` — New features (affects frontend, backend, or both)
- `fix/*` — Bug fixes
- `docs/*` — Documentation

### Commit Conventions

**Good commits:**
- `Add user profile feature across frontend and backend`
- `Update shared types for new post entity`
- `Fix CORS configuration for production environment`
- `Refactor API client to use shared constants`

**Before merging:**
- ✅ Frontend tests pass
- ✅ Backend tests pass
- ✅ Integration tests pass
- ✅ Shared types are up to date
- ✅ API documentation updated
- ✅ Design tokens used consistently
</git>

## Design Philosophy

<philosophy>
**Unified design system, clear separation of concerns, shared context.**

The full-stack application is a single product with two complementary parts. Design tokens and TypeScript types create a shared language between frontend and backend.

**OKLCH-driven design, modular architecture, production-ready always.**

OKLCH colors appear consistent across all surfaces—web UI, backend templates, emails, PDFs—because perceptual uniformity is built into the color model.

**Cohesive by default, maintainable through structure, scalable through modularity.**

Changes to shared types automatically propagate type safety to both frontend and backend. API contracts are enforced at compile time, not discovered at runtime.
</philosophy>

---

**When in doubt, check `/shared` first.** If you need a type, constant, or design token, it likely belongs in the shared directory where both frontend and backend can access it. Duplication is the enemy of consistency.
