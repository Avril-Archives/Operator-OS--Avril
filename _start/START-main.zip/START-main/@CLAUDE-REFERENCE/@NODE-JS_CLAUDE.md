# Node.js REST API Configuration

## Project Context

<context>
This is a Node.js REST API built with Express.js or Fastify, using TypeScript for type safety. The project emphasizes:

- **Clean architecture** with clear separation between routes, controllers, services, and models
- **Type safety** using TypeScript with strict mode enabled
- **Input validation** with Zod schemas for all API requests
- **Database access** via Drizzle ORM with PostgreSQL
- **Structured logging** using Pino for JSON-formatted logs
- **Security-first** with Helmet, CORS, rate limiting, and input sanitization

The architecture follows the principle of thin controllers with business logic isolated in service layers, making the codebase testable, maintainable, and scalable.
</context>

## Technical Stack

<stack>
- **Runtime:** Node.js ≥ 18 with ES Modules
- **Framework:** Express.js or Fastify
- **Language:** TypeScript with strict mode enabled
- **Validation:** Zod schemas for request/response validation
- **Database:** PostgreSQL with Drizzle ORM
- **Logging:** Pino (structured JSON logs)
- **Testing:** Vitest or Jest with supertest
- **Security:** Helmet, CORS, rate limiting
- **Encoding:** UTF-8 with LF line endings, 2-space indentation
</stack>

## Project Structure

<structure>
```
/src
 ├─ /routes               # API route definitions
 │   ├─ users.ts
 │   ├─ auth.ts
 │   └─ health.ts
 ├─ /controllers          # Thin HTTP request handlers
 │   ├─ user.controller.ts
 │   └─ auth.controller.ts
 ├─ /services             # Business logic layer
 │   ├─ user.service.ts
 │   └─ auth.service.ts
 ├─ /models               # Database schemas (Drizzle)
 │   ├─ user.model.ts
 │   └─ schema.ts
 ├─ /middlewares          # Express/Fastify middleware
 │   ├─ auth.middleware.ts
 │   ├─ validate.middleware.ts
 │   └─ error.middleware.ts
 ├─ /utils                # Helper functions
 │   ├─ formatters.ts
 │   ├─ validators.ts
 │   └─ logger.ts
 ├─ /types                # TypeScript type definitions
 │   └─ index.ts
 ├─ server.ts             # Server initialization
 └─ app.ts                # Express/Fastify app setup

/tests                    # Test files
 ├─ /unit
 └─ /integration

/docs                     # API documentation
 ├─ openapi.yaml
 └─ deployment.md
```
</structure>

## Working with Routes and Controllers

<conventions>
When creating or modifying API endpoints, follow these patterns:

### Thin Controllers

**Controllers should only handle HTTP concerns.** They parse requests, validate inputs, call services, and format responses. All business logic belongs in the service layer.

**Example: User Controller**
```typescript
// controllers/user.controller.ts
import { Request, Response, NextFunction } from 'express';
import { userService } from '../services/user.service';
import { createUserSchema, updateUserSchema } from '../schemas/user.schema';

export async function createUser(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    // Validate input with Zod
    const validated = createUserSchema.parse(req.body);

    // Delegate to service layer
    const user = await userService.create(validated);

    // Return structured response
    res.status(201).json({
      success: true,
      data: user
    });
  } catch (error) {
    next(error); // Pass to error handler
  }
}

export async function getUser(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    const { id } = req.params;
    const user = await userService.findById(id);

    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    res.status(200).json({
      success: true,
      data: user
    });
  } catch (error) {
    next(error);
  }
}

// ❌ Bad: Business logic in controller
export async function badCreateUser(req: Request, res: Response) {
  // Don't do database queries directly in controllers
  const user = await db.insert(users).values(req.body);
  // Don't put validation logic here
  // Don't put complex calculations here
}
```

### Service Layer

**All business logic, domain operations, and database interactions** happen in services.

**Example: User Service**
```typescript
// services/user.service.ts
import { db } from '../db';
import { users } from '../models/user.model';
import { eq } from 'drizzle-orm';
import { hashPassword } from '../utils/crypto';
import { logger } from '../utils/logger';

export const userService = {
  async create(data: CreateUserInput) {
    // Business logic: hash password
    const hashedPassword = await hashPassword(data.password);

    // Database operation
    const [user] = await db
      .insert(users)
      .values({
        ...data,
        password: hashedPassword,
        createdAt: new Date()
      })
      .returning();

    logger.info({ userId: user.id }, 'User created');

    // Don't return sensitive data
    const { password, ...safeUser } = user;
    return safeUser;
  },

  async findById(id: string) {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.id, id))
      .limit(1);

    if (user) {
      const { password, ...safeUser } = user;
      return safeUser;
    }

    return null;
  },

  async update(id: string, data: UpdateUserInput) {
    const [updated] = await db
      .update(users)
      .set({
        ...data,
        updatedAt: new Date()
      })
      .where(eq(users.id, id))
      .returning();

    if (!updated) {
      throw new Error('User not found');
    }

    logger.info({ userId: id }, 'User updated');
    const { password, ...safeUser } = updated;
    return safeUser;
  }
};
```

### Input Validation with Zod

**Every API endpoint must validate inputs** using Zod schemas before processing.

**Example: User Schemas**
```typescript
// schemas/user.schema.ts
import { z } from 'zod';

export const createUserSchema = z.object({
  email: z
    .string()
    .email('Invalid email format')
    .toLowerCase(),
  password: z
    .string()
    .min(8, 'Password must be at least 8 characters')
    .regex(/[A-Z]/, 'Password must contain an uppercase letter')
    .regex(/[0-9]/, 'Password must contain a number'),
  name: z
    .string()
    .min(2, 'Name must be at least 2 characters')
    .max(100, 'Name must be less than 100 characters')
});

export const updateUserSchema = createUserSchema.partial();

export const userIdSchema = z.object({
  id: z.string().uuid('Invalid user ID format')
});

// Type inference from schema
export type CreateUserInput = z.infer<typeof createUserSchema>;
export type UpdateUserInput = z.infer<typeof updateUserSchema>;
```

**Validation Middleware:**
```typescript
// middlewares/validate.middleware.ts
import { Request, Response, NextFunction } from 'express';
import { AnyZodObject, ZodError } from 'zod';

export function validate(schema: AnyZodObject) {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      await schema.parseAsync({
        body: req.body,
        params: req.params,
        query: req.query
      });
      next();
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({
          success: false,
          error: 'Validation failed',
          details: error.errors.map(e => ({
            field: e.path.join('.'),
            message: e.message
          }))
        });
      }
      next(error);
    }
  };
}
```

### Route Definition

**Organize routes by domain** with clear middleware chains.

**Example: User Routes**
```typescript
// routes/users.ts
import { Router } from 'express';
import * as userController from '../controllers/user.controller';
import { validate } from '../middlewares/validate.middleware';
import { authenticate } from '../middlewares/auth.middleware';
import { createUserSchema, updateUserSchema } from '../schemas/user.schema';

const router = Router();

// Public routes
router.post(
  '/',
  validate(createUserSchema),
  userController.createUser
);

// Protected routes (require authentication)
router.get(
  '/:id',
  authenticate,
  userController.getUser
);

router.patch(
  '/:id',
  authenticate,
  validate(updateUserSchema),
  userController.updateUser
);

router.delete(
  '/:id',
  authenticate,
  userController.deleteUser
);

export default router;
```

### Health Check Endpoint

**Always include a `/health` endpoint** for monitoring and load balancers.

```typescript
// routes/health.ts
import { Router, Request, Response } from 'express';

const router = Router();

router.get('/', async (req: Request, res: Response) => {
  // Optional: Check database connectivity
  try {
    // await db.execute('SELECT 1');

    res.status(200).json({
      status: 'ok',
      timestamp: new Date().toISOString(),
      uptime: process.uptime()
    });
  } catch (error) {
    res.status(503).json({
      status: 'error',
      timestamp: new Date().toISOString()
    });
  }
});

export default router;
```

### Error Handling

**Centralized error handling** with proper status codes and structured responses.

```typescript
// middlewares/error.middleware.ts
import { Request, Response, NextFunction } from 'express';
import { logger } from '../utils/logger';

export function errorHandler(
  error: Error,
  req: Request,
  res: Response,
  next: NextFunction
) {
  // Log error with context
  logger.error({
    err: error,
    req: {
      method: req.method,
      url: req.url,
      headers: req.headers
    }
  }, 'Request error');

  // Don't expose internal errors to clients
  if (error.name === 'ValidationError') {
    return res.status(400).json({
      success: false,
      error: 'Validation failed',
      message: error.message
    });
  }

  if (error.name === 'UnauthorizedError') {
    return res.status(401).json({
      success: false,
      error: 'Unauthorized',
      message: 'Invalid or expired token'
    });
  }

  // Generic error response
  res.status(500).json({
    success: false,
    error: 'Internal server error',
    message: process.env.NODE_ENV === 'development'
      ? error.message
      : 'An unexpected error occurred'
  });
}
```

### Security Middleware

**Apply security best practices** from the start.

```typescript
// app.ts
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';

const app = express();

// Security headers
app.use(helmet());

// CORS configuration
app.use(cors({
  origin: process.env.ALLOWED_ORIGINS?.split(',') || ['http://localhost:5173'],
  credentials: true
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP'
});
app.use('/api/', limiter);

// Body parsing
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Logging
app.use((req, res, next) => {
  logger.info({
    method: req.method,
    url: req.url,
    ip: req.ip
  }, 'Incoming request');
  next();
});
```
</conventions>

## Development Workflow

<development>
### Starting the Development Server

```bash
# Install dependencies
npm install

# Start development server with hot reload
npm run dev
```

The API will be available at `http://localhost:3000` with automatic restarts on file changes.

### Database Migrations

```bash
# Generate migration from schema changes
npm run db:generate

# Apply migrations
npm run db:migrate

# Seed database with test data
npm run db:seed
```

### When Making Changes

1. **Define the Zod schema first** — This ensures type safety
2. **Update the service layer** — Add or modify business logic
3. **Update controllers** — Handle new HTTP endpoints
4. **Add tests** — Write unit and integration tests
5. **Update OpenAPI docs** — Keep API documentation current
</development>

## Code Quality & Validation

<validation>
Run these commands before committing:

```bash
# Linting
npm run lint

# Auto-format code
npm run format

# Type checking
npm run type-check

# Run tests
npm run test

# Test coverage
npm run test:coverage

# Run all checks
npm run validate  # lint + type-check + test
```

**Quality Gates:**
- All tests pass
- No TypeScript errors
- No linting issues
- Test coverage ≥ 80%
- No security vulnerabilities (`npm audit`)
</validation>

## Making Edits

<guidance>
When I work on this codebase, I will:

### Maintain Architecture

- **Keep controllers thin** — Only HTTP concerns
- **Service layer for logic** — All business rules and database operations
- **Validate at the boundary** — Use Zod schemas for all inputs
- **Centralized error handling** — Don't repeat error logic

### Database Queries

- **Use ORM efficiently** — Avoid N+1 queries
- **Add indexes** — For frequently queried columns
- **Use prepared statements** — Drizzle handles this automatically
- **Paginate large result sets** — Don't return unbounded data

**Example: Efficient Query with Pagination**
```typescript
export async function listUsers(page = 1, limit = 20) {
  const offset = (page - 1) * limit;

  const [users, [{ count }]] = await Promise.all([
    db
      .select()
      .from(users)
      .limit(limit)
      .offset(offset),
    db
      .select({ count: sql<number>`count(*)` })
      .from(users)
  ]);

  return {
    data: users,
    pagination: {
      page,
      limit,
      total: count,
      pages: Math.ceil(count / limit)
    }
  };
}
```

### Adding New Endpoints

When creating new API endpoints:

1. **Define Zod schema** for request/response
2. **Create service method** with business logic
3. **Create controller method** as thin HTTP handler
4. **Add route** with validation middleware
5. **Write tests** for happy path and errors
6. **Update OpenAPI spec** for documentation

### Logging Best Practices

```typescript
import { logger } from '../utils/logger';

// ✅ Good: Structured logging with context
logger.info({ userId, action: 'login' }, 'User logged in');
logger.error({ err, userId }, 'Failed to update user');

// ❌ Bad: String concatenation
logger.info('User ' + userId + ' logged in');
```
</guidance>

## Deployment

<deployment>
### Building for Production

```bash
# Build TypeScript to JavaScript
npm run build

# Start production server
npm start
```

### Environment Variables

Required environment variables:

```env
NODE_ENV=production
PORT=3000
DATABASE_URL=postgresql://user:pass@host:5432/dbname
JWT_SECRET=your-secret-key-here
ALLOWED_ORIGINS=https://yourapp.com,https://www.yourapp.com
LOG_LEVEL=info
```

### Deployment Checklist

✅ Environment variables configured via secrets
✅ Database migrations applied
✅ Health check endpoint responding
✅ CORS configured for production origins
✅ Rate limiting enabled
✅ Logging configured (structured JSON)
✅ Error tracking enabled (Sentry, etc.)
✅ Gzip compression enabled

### Coolify Deployment

- **Build Command:** `npm run build`
- **Start Command:** `npm start`
- **Port:** `3000` (or `process.env.PORT`)
- **Health Check:** `GET /health` should return 200
- **Resource Limits:** Set memory and CPU limits
</deployment>

## Version Control

<git>
### Branch Strategy

- `main` — Production-ready code
- `feature/*` — New features
- `fix/*` — Bug fixes
- `docs/*` — Documentation updates

### Commit Conventions

**Good commits:**
- `Add user registration endpoint with email verification`
- `Fix authentication middleware token validation`
- `Update user service to include password reset logic`
- `Refactor database queries for better performance`

**Before merging:**
- ✅ All tests pass
- ✅ Type checking passes
- ✅ Linting passes
- ✅ Security audit passes (`npm audit`)
- ✅ API documentation updated
</git>

## Design Philosophy

<philosophy>
**Modular, typed, and secure by default.**

The architecture separates concerns:
- **Routes** define HTTP endpoints
- **Controllers** handle HTTP I/O
- **Services** contain business logic
- **Models** define data structures

This separation makes the codebase:
- **Testable** — Services can be unit tested independently
- **Maintainable** — Changes are localized
- **Scalable** — Easy to add features without cascading changes

**Clear separation of concerns, minimal surface area, production-ready always.**

Type safety via TypeScript catches errors at compile time. Input validation via Zod catches errors at runtime. Together, they create a robust system.

**Simple by design, robust through validation, scalable through structure.**

Every endpoint follows the same pattern: validate → service → response. This consistency makes the codebase predictable and easy to navigate.
</philosophy>

---

**When in doubt, validate.** It's better to reject invalid input early than to handle corrupt data downstream. Use Zod schemas liberally and let TypeScript enforce contracts at every boundary.
