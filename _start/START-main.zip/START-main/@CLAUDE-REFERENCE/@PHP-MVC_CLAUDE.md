# PHP MVC Backend Configuration

## Project Context

<context>
This is a PHP MVC application built with Laravel or Symfony, emphasizing clean architecture and modern PHP practices. The project focuses on:

- **MVC architecture** with clear separation between Controllers, Models, and Views
- **Service layer pattern** for complex business logic
- **Token-driven UI** using OKLCH design tokens in Blade/Twig templates
- **Type safety** with PHP 8.2+ strict types and property typing
- **PSR standards** following PSR-12 (coding style) and PSR-4 (autoloading)
- **ORM abstraction** using Eloquent (Laravel) or Doctrine (Symfony)

The architecture emphasizes maintainable code through established patterns, comprehensive validation, and semantic HTML templates that follow modern design principles.
</context>

## Technical Stack

<stack>
- **PHP:** ≥ 8.2 with strict types enabled
- **Framework:** Laravel 10+ or Symfony 6+
- **Coding Standard:** PSR-12 with PSR-4 autoloading
- **Templates:** Blade (Laravel) or Twig (Symfony) with OKLCH tokens
- **Database:** PostgreSQL/MySQL with Eloquent or Doctrine ORM
- **Testing:** PHPUnit or Pest
- **Linting:** PHP_CodeSniffer or PHP-CS-Fixer
- **Design:** OKLCH color tokens from `/shared/tokens.json`
- **Encoding:** UTF-8 with LF line endings, 4-space indentation
</stack>

## Project Structure

<structure>
```
/app                          # Application code
 ├─ /Http
 │   ├─ /Controllers          # Thin HTTP handlers
 │   │   ├─ UserController.php
 │   │   └─ AuthController.php
 │   ├─ /Middleware           # Request/response middleware
 │   └─ /Requests             # Form request validators
 │       ├─ CreateUserRequest.php
 │       └─ UpdateUserRequest.php
 ├─ /Models                   # Eloquent/Doctrine models
 │   └─ User.php
 ├─ /Services                 # Business logic layer
 │   ├─ UserService.php
 │   └─ AuthService.php
 └─ /Repositories             # Data access layer (optional)

/config                       # Configuration files
 ├─ app.php
 ├─ database.php
 └─ cache.php

/database                     # Database files
 ├─ /migrations               # Schema migrations
 └─ /seeders                  # Test data seeders

/public                       # Web root
 ├─ index.php
 └─ /assets                   # Compiled CSS/JS

/resources                    # Frontend resources
 ├─ /views                    # Blade/Twig templates
 │   ├─ /layouts
 │   │   └─ app.blade.php
 │   ├─ /components
 │   │   ├─ button.blade.php
 │   │   └─ card.blade.php
 │   └─ /users
 │       ├─ index.blade.php
 │       └─ show.blade.php
 └─ /css                      # Styles with tokens
     ├─ tokens.css            # From /shared/tokens.json
     └─ app.css

/routes                       # Route definitions
 ├─ web.php                   # Web routes
 └─ api.php                   # API routes

/tests                        # Test files
 ├─ /Unit
 └─ /Feature

/docs                         # Documentation
```
</structure>

## Working with Controllers and Models

<conventions>
When creating or modifying controllers and models, follow these patterns:

### Thin Controllers

**Controllers handle HTTP only.** Validation, business logic, and data access should be delegated.

**Example: User Controller (Laravel)**
```php
<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateUserRequest;
use App\Http\Requests\UpdateUserRequest;
use App\Services\UserService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Response;

class UserController extends Controller
{
    public function __construct(
        private readonly UserService $userService
    ) {}

    /**
     * Display a listing of users.
     */
    public function index(): JsonResponse
    {
        $users = $this->userService->getAllUsers();

        return response()->json([
            'success' => true,
            'data' => $users
        ]);
    }

    /**
     * Store a newly created user.
     */
    public function store(CreateUserRequest $request): JsonResponse
    {
        // Validation already handled by CreateUserRequest
        $validated = $request->validated();

        $user = $this->userService->createUser($validated);

        return response()->json([
            'success' => true,
            'data' => $user
        ], Response::HTTP_CREATED);
    }

    /**
     * Display the specified user.
     */
    public function show(int $id): JsonResponse
    {
        $user = $this->userService->getUserById($id);

        if (!$user) {
            return response()->json([
                'success' => false,
                'error' => 'User not found'
            ], Response::HTTP_NOT_FOUND);
        }

        return response()->json([
            'success' => true,
            'data' => $user
        ]);
    }

    /**
     * Update the specified user.
     */
    public function update(
        UpdateUserRequest $request,
        int $id
    ): JsonResponse {
        $validated = $request->validated();
        $user = $this->userService->updateUser($id, $validated);

        if (!$user) {
            return response()->json([
                'success' => false,
                'error' => 'User not found'
            ], Response::HTTP_NOT_FOUND);
        }

        return response()->json([
            'success' => true,
            'data' => $user
        ]);
    }
}
```

### Form Request Validation

**Use dedicated FormRequest classes** for validation logic.

**Example: Create User Request**
```php
<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rules\Password;

class CreateUserRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true; // Or implement authorization logic
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\Rule|array|string>
     */
    public function rules(): array
    {
        return [
            'email' => [
                'required',
                'email',
                'unique:users,email',
                'max:255'
            ],
            'name' => [
                'required',
                'string',
                'min:2',
                'max:100'
            ],
            'password' => [
                'required',
                'confirmed',
                Password::min(8)
                    ->mixedCase()
                    ->numbers()
                    ->symbols()
            ]
        ];
    }

    /**
     * Get custom messages for validator errors.
     */
    public function messages(): array
    {
        return [
            'email.required' => 'Email address is required',
            'email.unique' => 'This email is already registered',
            'password.min' => 'Password must be at least 8 characters'
        ];
    }
}
```

### Service Layer

**Business logic belongs in services**, not controllers.

**Example: User Service**
```php
<?php

namespace App\Services;

use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;

class UserService
{
    /**
     * Get all users.
     */
    public function getAllUsers(): Collection
    {
        return User::select(['id', 'name', 'email', 'created_at'])
            ->orderBy('created_at', 'desc')
            ->get();
    }

    /**
     * Get user by ID.
     */
    public function getUserById(int $id): ?User
    {
        return User::find($id);
    }

    /**
     * Create a new user.
     *
     * @param array<string, mixed> $data
     */
    public function createUser(array $data): User
    {
        $user = User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => Hash::make($data['password'])
        ]);

        Log::info('User created', ['user_id' => $user->id]);

        return $user;
    }

    /**
     * Update an existing user.
     *
     * @param array<string, mixed> $data
     */
    public function updateUser(int $id, array $data): ?User
    {
        $user = User::find($id);

        if (!$user) {
            return null;
        }

        if (isset($data['password'])) {
            $data['password'] = Hash::make($data['password']);
        }

        $user->update($data);

        Log::info('User updated', ['user_id' => $user->id]);

        return $user->fresh();
    }

    /**
     * Delete a user.
     */
    public function deleteUser(int $id): bool
    {
        $user = User::find($id);

        if (!$user) {
            return false;
        }

        $deleted = $user->delete();

        if ($deleted) {
            Log::info('User deleted', ['user_id' => $id]);
        }

        return $deleted;
    }
}
```

### Eloquent Models

**Define models with strict typing** and proper relationships.

**Example: User Model**
```php
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
    ];

    /**
     * Get the user's posts.
     */
    public function posts(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(Post::class);
    }
}
```
</conventions>

## Working with Templates

<template-conventions>
### Blade Templates with Design Tokens

**Use OKLCH design tokens** in your Blade templates for consistent styling.

**Example: Layout with Tokens**
```blade
{{-- resources/views/layouts/app.blade.php --}}
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Styles -->
    <link rel="stylesheet" href="{{ asset('css/tokens.css') }}">
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">

    @stack('styles')
</head>
<body>
    <div id="app">
        @include('layouts.navigation')

        <main class="main-content">
            @yield('content')
        </main>

        @include('layouts.footer')
    </div>

    @stack('scripts')
</body>
</html>
```

**Example: Component with Semantic HTML**
```blade
{{-- resources/views/components/card.blade.php --}}
@props([
    'title',
    'description' => '',
    'link' => null,
    'linkText' => 'Learn more'
])

<article {{ $attributes->merge(['class' => 'card']) }}>
    <header class="card__header">
        <h3 class="card__title">{{ $title }}</h3>
    </header>

    @if($description)
        <div class="card__body">
            <p class="card__description">{{ $description }}</p>
        </div>
    @endif

    @if($link)
        <footer class="card__footer">
            <a href="{{ $link }}" class="card__link">
                {{ $linkText }}
            </a>
        </footer>
    @endif

    {{ $slot }}
</article>
```

**Usage:**
```blade
<x-card
    title="User Profile"
    description="Manage your account settings"
    link="{{ route('profile.edit') }}"
    class="featured"
>
    <div class="card__extra">
        Additional content here
    </div>
</x-card>
```

### CSS with Design Tokens

**tokens.css derived from /shared/tokens.json:**
```css
/* resources/css/tokens.css */
:root {
    /* Colors - OKLCH format */
    --color-primary: oklch(0.5 0.2 220);
    --color-surface: oklch(0.95 0.01 220);
    --color-text: oklch(0.2 0.01 220);
    --color-text-muted: oklch(0.5 0.01 220);
    --color-border: oklch(0.85 0.01 220);
    --color-success: oklch(0.6 0.15 145);
    --color-error: oklch(0.6 0.2 25);

    /* Spacing - 4px base scale */
    --spacing-xs: 4px;
    --spacing-sm: 8px;
    --spacing-md: 16px;
    --spacing-lg: 24px;
    --spacing-xl: 32px;
    --spacing-2xl: 48px;

    /* Typography */
    --font-family-base: Inter, system-ui, sans-serif;
    --font-family-mono: "JetBrains Mono", Consolas, monospace;
    --font-size-sm: 14px;
    --font-size-base: 16px;
    --font-size-lg: 18px;
    --font-size-xl: 24px;
    --line-height-base: 1.5;
}
```

**Component styles:**
```css
/* resources/css/components/card.css */
.card {
    background: var(--color-surface);
    border: 1px solid var(--color-border);
    border-radius: var(--spacing-xs);
    padding: var(--spacing-lg);
    font-family: var(--font-family-base);
}

.card__title {
    font-size: var(--font-size-lg);
    color: var(--color-text);
    margin: 0 0 var(--spacing-md) 0;
}

.card__description {
    color: var(--color-text-muted);
    line-height: var(--line-height-base);
}

.card__link {
    color: var(--color-primary);
    text-decoration: none;
}

.card__link:hover {
    text-decoration: underline;
}
```
</template-conventions>

## Development Workflow

<development>
### Starting the Development Server

**Laravel:**
```bash
# Install dependencies
composer install

# Copy environment file
cp .env.example .env

# Generate application key
php artisan key:generate

# Run migrations
php artisan migrate

# Seed database (optional)
php artisan db:seed

# Start development server
php artisan serve
```

**Symfony:**
```bash
composer install
symfony server:start
```

The application will be available at `http://localhost:8000`

### Database Migrations

**Laravel:**
```bash
# Create migration
php artisan make:migration create_users_table

# Run migrations
php artisan migrate

# Rollback last migration
php artisan migrate:rollback

# Refresh database (drop all tables and re-migrate)
php artisan migrate:fresh --seed
```

### When Making Changes

1. **Add validation rules** in FormRequest classes
2. **Implement business logic** in Service layer
3. **Keep controllers thin** — Delegate to services
4. **Update templates** — Use design tokens, maintain accessibility
5. **Write tests** — Feature tests for endpoints, unit tests for services
</development>

## Code Quality & Validation

<validation>
Run these commands before committing:

```bash
# PSR-12 code style check
composer lint
# OR
./vendor/bin/php-cs-fixer fix --dry-run --diff

# Auto-fix code style
composer format
# OR
./vendor/bin/php-cs-fixer fix

# Run tests
composer test
# OR
php artisan test
./vendor/bin/phpunit

# Run specific test suite
php artisan test --testsuite=Feature
```

**Quality Gates:**
- PSR-12 compliance
- All tests pass
- No security vulnerabilities
- Proper type hints throughout
- Templates use design tokens
</validation>

## Making Edits

<guidance>
When I work on this codebase, I will:

### Maintain MVC Architecture

- **Thin controllers** — Only HTTP request/response handling
- **Service layer** — Business logic and orchestration
- **Models** — Data access and relationships
- **Templates** — Presentation with design tokens

### Follow Laravel/Symfony Conventions

- Use framework features (validation, middleware, ORM)
- Follow naming conventions (StudlyCase for classes, snake_case for methods)
- Leverage dependency injection
- Use framework-provided security features

### Template Best Practices

- **Semantic HTML** — Use proper elements (`<article>`, `<section>`, etc.)
- **Design tokens** — Never hardcode colors, spacing, or typography
- **Accessibility** — ARIA labels, keyboard navigation, proper form labels
- **Components** — Create reusable Blade components for common UI patterns

**Example: Adding a New Feature**

1. **Create migration:**
```bash
php artisan make:migration create_posts_table
```

2. **Create model:**
```bash
php artisan make:model Post
```

3. **Create service:**
```php
// app/Services/PostService.php
class PostService {
    public function getAllPosts() { /* ... */ }
    public function createPost(array $data) { /* ... */ }
}
```

4. **Create FormRequest:**
```bash
php artisan make:request CreatePostRequest
```

5. **Create controller:**
```bash
php artisan make:controller PostController --resource
```

6. **Add routes:**
```php
// routes/web.php
Route::resource('posts', PostController::class);
```

7. **Create templates:**
```blade
{{-- resources/views/posts/index.blade.php --}}
@extends('layouts.app')

@section('content')
    <div class="posts-container">
        @foreach($posts as $post)
            <x-card
                title="{{ $post->title }}"
                description="{{ $post->excerpt }}"
                link="{{ route('posts.show', $post) }}"
            />
        @endforeach
    </div>
@endsection
```
</guidance>

## Deployment

<deployment>
### Building for Production

**Laravel:**
```bash
# Install production dependencies only
composer install --no-dev --optimize-autoloader

# Cache configuration
php artisan config:cache

# Cache routes
php artisan route:cache

# Cache views
php artisan view:cache

# Optimize autoloader
composer dump-autoload --optimize
```

### Environment Configuration

Required `.env` variables:

```env
APP_NAME=Laravel
APP_ENV=production
APP_KEY=base64:...
APP_DEBUG=false
APP_URL=https://yourapp.com

DB_CONNECTION=pgsql
DB_HOST=127.0.0.1
DB_PORT=5432
DB_DATABASE=your_database
DB_USERNAME=your_username
DB_PASSWORD=your_password

CACHE_DRIVER=redis
SESSION_DRIVER=redis
QUEUE_CONNECTION=redis
```

### Deployment Checklist

✅ Production environment file configured
✅ Application key generated
✅ Database migrations applied
✅ OPcache enabled
✅ Config, routes, views cached
✅ Health check endpoint working
✅ CORS configured for API routes
✅ Error reporting configured (Sentry, etc.)

### Coolify Deployment

- **Web Root:** `/public`
- **PHP Version:** 8.2+
- **Extensions:** PDO, Mbstring, OpenSSL, JSON, Tokenizer
- **Dockerfile:** Include PHP-FPM + Nginx
</deployment>

## Version Control

<git>
### Branch Strategy

- `main` — Production-ready code
- `feature/*` — New features
- `fix/*` — Bug fixes
- `docs/*` — Documentation

### Commit Conventions

**Good commits:**
- `Add user profile editing feature with validation`
- `Fix authentication middleware session handling`
- `Update user service to handle password resets`
- `Refactor post queries for better performance`

**Before merging:**
- ✅ All tests pass
- ✅ PSR-12 compliance
- ✅ No security vulnerabilities
- ✅ Templates use design tokens
- ✅ Accessibility requirements met
</git>

## Design Philosophy

<philosophy>
**Structured, semantic, and token-driven.**

PHP MVC architecture provides clear boundaries:
- **Models** manage data
- **Views** present information
- **Controllers** coordinate requests
- **Services** implement business logic

This structure makes applications maintainable at scale.

**Service-layer logic, template-based UI, production-ready always.**

The service layer isolates business logic from HTTP concerns, making code testable and reusable across different interfaces (web, API, CLI).

**Clean by design, maintainable through patterns, scalable through structure.**

Following established patterns (PSR standards, MVC architecture, service layer) creates consistency. Future developers can navigate the codebase intuitively.
</philosophy>

---

**When in doubt, delegate.** Controllers delegate to services. Services delegate to repositories or models. Each layer has a single responsibility, making the system easier to understand, test, and maintain.
