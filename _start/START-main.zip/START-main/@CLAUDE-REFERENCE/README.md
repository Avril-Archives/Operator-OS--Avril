# Claude Code Configuration Reference

A comprehensive collection of CLAUDE.md templates for modern full-stack development with OKLCH-driven design systems.

## Overview

This collection provides specialized CLAUDE.md configuration files for different project types, optimized for Claude Code's hierarchical context system. Each template follows Claude.md best practices with conversational guidance, structured context, and clear intent.

**Core Philosophy:**
- Mobile-first design with responsive layouts (320–1440px)
- OKLCH color model for perceptual color harmony
- Monochrome palette with purposeful color signals
- 4px base spacing scale for consistent vertical rhythm
- Token-driven design from `/shared/tokens.json`
- No flex-wrap — use scroll, truncation, or overflow
- Semantic HTML with mandatory accessibility

## Available Configurations

### Frontend

**[@REACT-VITE_CLAUDE.md](./@REACT-VITE_CLAUDE.md)**
React 18+ with Vite bundler, component-driven architecture, and modern hooks patterns.

**[@STATIC_CLAUDE.md](./@STATIC_CLAUDE.md)**
Zero-build static HTML/CSS/JS projects with vanilla JavaScript and token-driven CSS.

### Backend

**[@NODE-JS_CLAUDE.md](./@NODE-JS_CLAUDE.md)**
Node.js REST APIs with Express/Fastify, TypeScript, Zod validation, and Drizzle ORM.

**[@FastAPI_CLAUDE.md](./@FastAPI_CLAUDE.md)**
Python FastAPI microservices with async patterns, Pydantic models, and auto-generated docs.

**[@PHP-MVC_CLAUDE.md](./@PHP-MVC_CLAUDE.md)**
Laravel/Symfony MVC applications with Blade/Twig templates and Eloquent/Doctrine ORM.

### Full-Stack

**[@FULLSTACK_CLAUDE.md](./@FULLSTACK_CLAUDE.md)**
Integrated frontend and backend projects with shared design tokens and unified architecture.

## Quick Start

### 1. Choose Your Project Type

Select the configuration that matches your project structure from the list above.

### 2. Copy to Your Project

For Claude Code, place the configuration in your project's `.claude` directory:

```bash
# Example: React + Vite project
cp @CLAUDE-REFERENCE/@REACT-VITE_CLAUDE.md .claude/CLAUDE.md
```

### 3. Create Design Token System

Set up `/shared/tokens.json` with your design tokens:

```json
{
  "colors": {
    "primary": "oklch(0.5 0.2 220)",
    "surface": "oklch(0.95 0.01 220)",
    "text": "oklch(0.2 0.01 220)",
    "text-muted": "oklch(0.5 0.01 220)",
    "border": "oklch(0.85 0.01 220)",
    "success": "oklch(0.6 0.15 145)",
    "warning": "oklch(0.7 0.15 85)",
    "error": "oklch(0.6 0.2 25)"
  },
  "spacing": {
    "xs": "4px",
    "sm": "8px",
    "md": "16px",
    "lg": "24px",
    "xl": "32px",
    "2xl": "48px",
    "3xl": "64px"
  },
  "typography": {
    "font-family-base": "Inter, system-ui, sans-serif",
    "font-family-mono": "JetBrains Mono, Consolas, monospace",
    "font-size-xs": "12px",
    "font-size-sm": "14px",
    "font-size-base": "16px",
    "font-size-lg": "18px",
    "font-size-xl": "24px",
    "font-size-2xl": "32px",
    "line-height-tight": "1.25",
    "line-height-base": "1.5",
    "line-height-relaxed": "1.75"
  }
}
```

### 4. Reference Tokens in CSS

```css
:root {
  /* Colors */
  --color-primary: oklch(0.5 0.2 220);
  --color-surface: oklch(0.95 0.01 220);
  --color-text: oklch(0.2 0.01 220);

  /* Spacing */
  --spacing-xs: 4px;
  --spacing-sm: 8px;
  --spacing-md: 16px;
  --spacing-lg: 24px;
  --spacing-xl: 32px;

  /* Typography */
  --font-family-base: Inter, system-ui, sans-serif;
  --font-family-mono: JetBrains Mono, Consolas, monospace;
  --font-size-base: 16px;
  --line-height-base: 1.5;
}

body {
  font-family: var(--font-family-base);
  font-size: var(--font-size-base);
  line-height: var(--line-height-base);
  color: var(--color-text);
  background: var(--color-surface);
}
```

### 5. Work with Claude Code

Claude Code will automatically discover and use your `.claude/CLAUDE.md` configuration, providing context-aware assistance for your specific project type.

## CLAUDE.md vs AGENTS.md

### Key Differences

| Aspect | AGENTS.md | CLAUDE.md |
|--------|-----------|-----------|
| **Format** | Rule-based, imperative | Conversational, guidance-oriented |
| **Structure** | Flat sections | XML-tagged, hierarchical |
| **Tone** | Directive ("Do this") | Collaborative ("When you work on...") |
| **Context** | Static rules | Dynamic guidance with examples |
| **Hierarchy** | Single file | Nested across directories |
| **Tool Support** | Universal (Cursor, Copilot, etc.) | Claude Code optimized |

### When to Use Each

**Use CLAUDE.md when:**
- Working primarily with Claude Code
- Need hierarchical context (monorepo, complex projects)
- Want conversational, intent-based guidance
- Need rich examples and context blocks
- Prefer structured XML-style organization

**Use AGENTS.md when:**
- Need universal AI tool compatibility
- Want simple, portable configuration
- Prefer concise, rule-based format
- Working with multiple AI coding assistants
- Need quick setup with minimal structure

### Can I Use Both?

Yes! You can maintain both formats:

```bash
/project
 ├─ AGENTS.md           # Universal format
 └─ .claude/
     └─ CLAUDE.md       # Claude Code specific
```

Claude Code will prioritize `.claude/CLAUDE.md` if present, falling back to root-level configuration files if needed.

## Best Practices

### Configuration Maintenance

✅ **Review on architectural changes** — Update when adding major features or refactoring
✅ **Keep examples current** — Ensure code samples reflect actual project patterns
✅ **Use hierarchical nesting** — Place domain-specific configs in subdirectories
✅ **Link to detailed docs** — Reference external documentation instead of duplicating
✅ **Treat as living documentation** — Evolve with your codebase

### Effective Claude.md Structure

✅ **Use XML-style tags** — `<context>`, `<conventions>`, `<examples>` for structure
✅ **Be conversational** — Write as if instructing a collaborator
✅ **Provide intent** — Explain *why* not just *what*
✅ **Include examples** — Show concrete implementations
✅ **Layer context** — Use nested files for different project areas

### Anti-Patterns to Avoid

❌ **Vague instructions** — "Write good code" provides no actionable guidance
❌ **Outdated examples** — Deprecated patterns confuse and mislead
❌ **Excessive duplication** — Link to documentation instead of copying
❌ **Missing reasoning** — Always explain the "why" behind rules
❌ **Overly broad scope** — Use nested configs for specific domains

## File Organization

### Simple Project Structure

```
/project
 └─ .claude/
     └─ CLAUDE.md       # Main configuration
```

### Monorepo Structure

```
/project
 ├─ .claude/
 │   └─ CLAUDE.md       # Root-level guidance
 ├─ /frontend
 │   └─ .claude/
 │       └─ CLAUDE.md   # Frontend-specific
 ├─ /backend
 │   └─ .claude/
 │       └─ CLAUDE.md   # Backend-specific
 └─ /shared
     └─ .claude/
         └─ CLAUDE.md   # Shared types/utilities
```

Claude Code automatically discovers and hierarchically applies configuration from parent to child directories.

## Validation Commands

Each CLAUDE.md template includes validation commands for ensuring code quality:

### Frontend

```bash
npm run lint          # ESLint
npm run format        # Prettier
npm run test          # Vitest/Jest
npm run test:coverage # Coverage report
npm run build         # Production build
npx lighthouse http://localhost:5173 --view
```

### Backend

```bash
# Node.js
npm run lint && npm run test && npm run type-check

# Python
pytest && ruff check . && mypy app

# PHP
composer test && composer lint
```

### Accessibility & Performance

```bash
# Lighthouse audit
npx lighthouse http://localhost:8080 --view

# HTML validation
npx html-validate "**/*.html"

# CSS validation
npx stylelint "**/*.css" --fix

# Accessibility testing
npx axe-cli http://localhost:8080
```

## Design Philosophy

### Core Principles

**Purposeful Minimalism** — Eliminate all non-essential elements
**Monochrome Discipline** — Maintain visual clarity with grayscale base
**Spatial Hierarchy** — Use spacing and layout to guide attention
**Subtle Sophistication** — Refined, restrained interactions
**Functional Beauty** — Elevate both form and function
**Consistent Rhythm** — Predictable visual cadence across viewports

### Technical Standards

- **24-column fluid grid** for responsive layouts
- **Mathematical spacing scale** (4px base: 4, 8, 16, 24, 32, 48, 64)
- **OKLCH color model** for perceptual uniformity
- **Flexbox layouts** with intentional scroll patterns (no flex-wrap)
- **Progressive disclosure** for layered complexity
- **Strategic whitespace** for structure and contrast

## Resources

### Official Documentation

- [Claude Code Documentation](https://docs.claude.com/en/docs/claude-code)
- [CLAUDE.md Specification](https://docs.claude.com/en/docs/claude-code/claude-md)
- [Hierarchical Context Guide](https://docs.claude.com/en/docs/claude-code/context-hierarchy)

### Design Resources

- [OKLCH Color Picker](https://oklch.com)
- [Inter Font](https://rsms.me/inter/)
- [JetBrains Mono](https://www.jetbrains.com/lp/mono/)
- [Phosphor Icons](https://phosphoricons.com)

### Complementary Standards

- [AGENTS.md Reference](../@AGENTS-REFERENCE/README.md) — Universal AI tool format
- [Cursor Rules Guide](https://cursor.com/docs/context/rules)
- [GitHub Copilot Instructions](https://docs.github.com/copilot)

## Contributing

Contributions welcome! Please:

1. Follow existing structure and tone
2. Use conversational, guidance-oriented language
3. Include concrete examples and context
4. Test with Claude Code
5. Document reasoning behind guidance
6. Keep files focused and concise

## Migration from AGENTS.md

### Quick Conversion Steps

1. **Copy template structure** — Use provided templates as starting point
2. **Convert rules to guidance** — Transform imperatives to collaborative tone
3. **Add context blocks** — Wrap sections in XML-style tags
4. **Include examples** — Add concrete code samples
5. **Explain intent** — Document the "why" behind each convention
6. **Test with Claude** — Verify configuration works as expected

### Example Transformation

**AGENTS.md (Rule-based):**
```markdown
## Authoring Rules

- Keep controllers thin; all business logic in service layer
- Validate all inputs with Zod
```

**CLAUDE.md (Guidance-based):**
```markdown
<conventions>
When working with API endpoints, follow these patterns:

**Controller Layer**
Keep controllers focused on HTTP concerns (request/response handling).
They should be thin adapters that delegate to the service layer.

Example:
```typescript
// ✅ Good: Thin controller
export async function createUser(req: Request, res: Response) {
  const validated = userSchema.parse(req.body);
  const user = await userService.create(validated);
  res.status(201).json(user);
}
```

**Validation**
All inputs must be validated using Zod schemas before processing.
This ensures type safety and provides clear error messages to clients.
</conventions>
```

## License

MIT — Use freely for personal or commercial projects.

---

**Philosophy:** READMEs are for humans; CLAUDE.md is for Claude Code.

Start with tokens, design with intention, validate relentlessly.
