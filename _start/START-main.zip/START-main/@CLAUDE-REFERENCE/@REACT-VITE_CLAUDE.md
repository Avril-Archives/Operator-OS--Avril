# React + Vite Frontend Configuration

## Project Context

<context>
This is a React 18+ application built with Vite as the build tool. The project emphasizes:

- **Component-driven architecture** with small, composable, single-responsibility components
- **Token-driven design** using OKLCH color values from `/shared/tokens.json`
- **Mobile-first responsive design** supporting viewports from 320px to 1440px
- **Accessibility-first development** with mandatory ARIA labels and keyboard navigation
- **Performance optimization** through code splitting, lazy loading, and minimal bundle size

The design philosophy centers on purposeful minimalism: every element must serve a clear function, visual bloat is eliminated, and the monochrome palette with strategic color accents creates a sophisticated, clean interface.
</context>

## Technical Stack

<stack>
- **React 18+** with functional components and hooks
- **Vite** for fast bundler with ES modules and HMR
- **CSS Variables** with OKLCH color tokens from `/shared/tokens.json`
- **Fonts:** Inter (UI), JetBrains Mono (code/monospace)
- **Icons:** Phosphor Icons via CDN
- **Testing:** Vitest + React Testing Library
- **Styling:** CSS Modules or vanilla CSS with semantic variables
- **Encoding:** UTF-8 with LF line endings, 2-space indentation
</stack>

## Project Structure

<structure>
```
/src
 ├─ /components          # Reusable UI components
 │   ├─ Button.jsx
 │   ├─ Card.jsx
 │   ├─ Modal.jsx
 │   └─ Layout.jsx
 ├─ /pages               # Route-level page components
 │   ├─ Home.jsx
 │   ├─ Dashboard.jsx
 │   └─ Settings.jsx
 ├─ /hooks               # Custom React hooks
 │   ├─ useAuth.js
 │   ├─ useFetch.js
 │   └─ useTheme.js
 ├─ /styles              # Global styles and tokens
 │   ├─ tokens.css       # Design system variables
 │   ├─ reset.css        # CSS reset/normalize
 │   ├─ layout.css       # Layout utilities
 │   └─ components.css   # Component-specific styles
 ├─ /utils               # Helper functions
 │   ├─ formatters.js
 │   ├─ validators.js
 │   └─ api-client.js
 ├─ /assets              # Static assets
 │   ├─ /images
 │   └─ /icons
 ├─ App.jsx              # Root component
 └─ main.jsx             # Entry point

/public                  # Static files served as-is
 ├─ manifest.json
 ├─ robots.txt
 └─ favicon.ico

/tests                   # Test files
/docs                    # Project documentation
```
</structure>

## Working with Components

<conventions>
When creating or modifying React components, follow these patterns:

### Component Structure

**Keep components small and focused.** Each component should have a single, clear responsibility. If a component is doing too much, split it into smaller pieces.

**Example: Button Component**
```jsx
// ✅ Good: Small, focused, composable
export function Button({
  children,
  variant = 'primary',
  size = 'md',
  disabled = false,
  onClick,
  ...props
}) {
  return (
    <button
      className={`btn btn--${variant} btn--${size}`}
      disabled={disabled}
      onClick={onClick}
      {...props}
    >
      {children}
    </button>
  );
}

// ❌ Bad: Too many responsibilities
export function ButtonWithIconAndTooltipAndLoading() {
  // Combines multiple concerns - split into separate components
}
```

### Co-located Styles

**Never hardcode colors, spacing, or typography values.** Always use semantic CSS variables from `tokens.css`.

**Example: Using Design Tokens**
```css
/* tokens.css */
:root {
  --color-primary: oklch(0.5 0.2 220);
  --color-surface: oklch(0.95 0.01 220);
  --color-text: oklch(0.2 0.01 220);
  --spacing-md: 16px;
  --spacing-lg: 24px;
  --font-family-base: Inter, system-ui, sans-serif;
}

/* Button.css */
.btn {
  font-family: var(--font-family-base);
  padding: var(--spacing-md) var(--spacing-lg);
  background: var(--color-primary);
  color: var(--color-surface);
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

/* ❌ Bad: Hardcoded values */
.btn-bad {
  padding: 16px 24px; /* Should use var(--spacing-*) */
  background: #3b82f6; /* Should use OKLCH variable */
}
```

### Accessibility Requirements

**Every interactive element must be fully accessible.** This is non-negotiable.

**Checklist:**
- ✅ All form inputs have associated `<label>` elements
- ✅ Interactive elements have clear focus states
- ✅ Keyboard navigation works for all interactions
- ✅ ARIA labels provided where semantic HTML isn't sufficient
- ✅ Focus order is logical and predictable
- ✅ Color is not the only indicator of state

**Example: Accessible Modal**
```jsx
export function Modal({ isOpen, onClose, title, children }) {
  const modalRef = useRef(null);

  useEffect(() => {
    if (isOpen) {
      // Trap focus within modal
      modalRef.current?.focus();

      // Prevent body scroll
      document.body.style.overflow = 'hidden';
    }

    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div
      className="modal-overlay"
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
    >
      <div
        className="modal-content"
        ref={modalRef}
        tabIndex={-1}
      >
        <header className="modal-header">
          <h2 id="modal-title">{title}</h2>
          <button
            onClick={onClose}
            aria-label="Close modal"
            className="modal-close"
          >
            ×
          </button>
        </header>
        <div className="modal-body">
          {children}
        </div>
      </div>
    </div>
  );
}
```

### Performance Optimization

**Lazy load routes and memoize expensive operations.**

```jsx
// Lazy load route components
const Dashboard = lazy(() => import('./pages/Dashboard'));
const Settings = lazy(() => import('./pages/Settings'));

function App() {
  return (
    <Suspense fallback={<LoadingSpinner />}>
      <Routes>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/settings" element={<Settings />} />
      </Routes>
    </Suspense>
  );
}

// Memoize expensive calculations
function DataTable({ data, filters }) {
  const filteredData = useMemo(() => {
    return data.filter(item => matchesFilters(item, filters));
  }, [data, filters]);

  const handleSort = useCallback((column) => {
    // Memoized callback to prevent re-renders
  }, []);

  return <Table data={filteredData} onSort={handleSort} />;
}
```

### Layout Conventions

**No flex-wrap anywhere.** Use horizontal scroll or truncation for overflow content.

```css
/* ✅ Good: Horizontal scroll for overflow */
.card-list {
  display: flex;
  gap: var(--spacing-md);
  overflow-x: auto;
  scroll-behavior: smooth;
}

/* ❌ Bad: Wrapping content */
.card-list-bad {
  display: flex;
  flex-wrap: wrap; /* Never use this */
}

/* ✅ Good: Truncate text overflow */
.card-title {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
```

### Image Optimization

**Use modern formats with explicit dimensions.**

```jsx
// ✅ Good: Optimized image with fallback
<picture>
  <source srcSet="/hero.avif" type="image/avif" />
  <source srcSet="/hero.webp" type="image/webp" />
  <img
    src="/hero.jpg"
    alt="Hero image showing product interface"
    width="1200"
    height="600"
    loading="lazy"
  />
</picture>

// ❌ Bad: No dimensions, old format
<img src="/hero.png" alt="hero" />
```
</conventions>

## Development Workflow

<development>
### Starting the Development Server

```bash
# Install dependencies
npm install

# Start dev server with HMR
npm run dev
```

The application will be available at `http://localhost:5173` with hot module replacement enabled.

### Optional Type Checking

If using TypeScript or JSDoc annotations:

```bash
npm run type-check
```

### When Making Changes

1. **Read the component first** — Understand existing patterns before modifying
2. **Make scoped edits** — Preserve component structure and naming conventions
3. **Extend utilities** — Add to existing utility functions rather than duplicating logic
4. **Update tests** — Modify tests to match component changes
5. **Test accessibility** — Verify keyboard navigation and screen reader compatibility
</development>

## Code Quality & Validation

<validation>
Before committing changes, run these validation commands:

```bash
# Linting
npm run lint

# Auto-format code
npm run format

# Run tests
npm run test

# Test coverage report
npm run test:coverage

# Production build (ensures no build errors)
npm run build

# Performance & accessibility audit
npx lighthouse http://localhost:5173 --view
```

**Quality Gates:**
- All tests must pass
- No linting errors
- Lighthouse scores ≥ 90 for Performance, Accessibility, SEO
- Bundle size increase should be justified
</validation>

## Making Edits

<guidance>
When I work on this codebase, I will:

### Preserve Existing Patterns

- **Respect component structure** — Don't reorganize files without good reason
- **Follow naming conventions** — Match existing patterns for files and functions
- **Keep dependencies minimal** — Only add new packages when necessary, with justification
- **Extend, don't duplicate** — Add to utility hooks or helpers rather than creating similar functions

### Component Updates

When modifying components:

1. **Read the full component first** to understand its current implementation
2. **Make targeted changes** — Only edit what's necessary
3. **Update associated tests** — Ensure tests reflect the changes
4. **Update Storybook stories** (if applicable) — Keep documentation current
5. **Comment complex logic** — Explain the intent behind state management or intricate hooks

### Adding New Features

When adding new functionality:

1. **Check for existing utilities** — Don't reinvent what already exists
2. **Extend the design token system** — Add new tokens to `/shared/tokens.json` if needed
3. **Create reusable components** — Build for composability
4. **Write tests first** (TDD) or immediately after implementation
5. **Document complex patterns** — Add comments explaining non-obvious decisions

### Example: Adding a New Hook

```jsx
// ✅ Good: Well-documented custom hook
/**
 * Fetches data from an API endpoint with loading and error states.
 *
 * @param {string} url - The API endpoint URL
 * @param {object} options - Fetch options (headers, method, etc.)
 * @returns {object} { data, loading, error, refetch }
 *
 * @example
 * const { data, loading, error } = useFetch('/api/users');
 */
export function useFetch(url, options = {}) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      const response = await fetch(url, options);
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const json = await response.json();
      setData(json);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [url, options]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { data, loading, error, refetch: fetchData };
}
```
</guidance>

## Deployment

<deployment>
### Building for Production

```bash
npm run build
```

This outputs optimized static files to the `/dist` directory.

### Deployment Checklist

✅ Production build completes without errors
✅ All environment variables configured correctly
✅ Cache headers set for `/dist/assets/*`
✅ Gzip or Brotli compression enabled
✅ Lighthouse audit scores ≥ 90
✅ Meta tags and OG tags present in `index.html`
✅ Favicon and manifest.json configured

### Coolify Static Build Pack

When deploying via Coolify:
- **Build Command:** `npm run build`
- **Output Directory:** `dist`
- **Cache Strategy:** Cache `/dist/assets` with long TTL (1 year)
- **Compression:** Enable Brotli compression (better than gzip)
</deployment>

## Version Control

<git>
### Branch Strategy

- `main` — Production-ready code
- `feature/*` — New features (e.g., `feature/user-dashboard`)
- `fix/*` — Bug fixes (e.g., `fix/modal-focus-trap`)
- `docs/*` — Documentation updates

### Commit Conventions

Write commits in the imperative mood: "Add feature" not "Added feature"

**Good commit messages:**
- `Add user profile component with avatar upload`
- `Fix focus trap in modal component`
- `Update button styles to use design tokens`
- `Refactor useFetch hook for better error handling`

**Before merging:**
- ✅ All tests pass
- ✅ Linting passes with no errors
- ✅ Accessibility audit passes
- ✅ Performance metrics meet thresholds
</git>

## Design Philosophy

<philosophy>
**Component-driven, token-first, and relentlessly accessible.**

Every component should:
- Serve a single, clear purpose
- Derive all visual properties from design tokens
- Be fully accessible via keyboard and screen readers
- Perform efficiently with minimal re-renders
- Compose naturally with other components

**OKLCH-driven design, minimal bundle size, and production-ready always.**

The color system uses OKLCH for perceptual uniformity — colors at the same lightness value appear equally bright to the human eye, creating visual harmony.

**Fast by default, beautiful by design, scalable through modularity.**

Code splitting, lazy loading, and memoization are standard practices, not optimizations applied later. Build performance in from the start.
</philosophy>

---

**When in doubt, ask about intent.** If requirements are unclear, request clarification before implementing. It's better to understand the goal than to build the wrong solution quickly.
