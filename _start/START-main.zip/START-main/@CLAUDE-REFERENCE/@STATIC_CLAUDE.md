# Static Web Project Configuration

## Project Context

<context>
This is a zero-build static website project using vanilla HTML, CSS, and JavaScript. The project emphasizes:

- **Separation of concerns** with strict boundaries between structure (HTML), presentation (CSS), and behavior (JS)
- **Token-driven design** using OKLCH color values from `/shared/tokens.json`
- **Mobile-first responsive design** supporting viewports from 320px to 1440px
- **Semantic HTML5** with proper accessibility attributes
- **Zero build complexity** — works directly in browsers without compilation

The design philosophy centers on timeless, portable code that will work for years without dependency updates or build tool migrations.
</context>

## Technical Stack

<stack>
- **HTML5** with semantic markup and ARIA attributes
- **Vanilla JavaScript** using ES modules (no frameworks)
- **CSS Variables** with OKLCH color tokens from `/shared/tokens.json`
- **Fonts:** Inter (UI), JetBrains Mono (code/monospace)
- **Icons:** Phosphor Icons via CDN
- **Development:** Simple HTTP server (Python, Node.js, or browser-sync)
- **Encoding:** UTF-8 with LF line endings, 2-space indentation
</stack>

## Project Structure

<structure>
```
/frontend-static
 ├─ index.html                # Main entry point
 ├─ /templates                # Reusable HTML fragments
 │   ├─ base.html
 │   ├─ section.html
 │   ├─ card.html
 │   └─ modal.html
 ├─ /scripts                  # JavaScript modules
 │   ├─ app.js                # Main application logic
 │   ├─ filters.js            # Data filtering utilities
 │   └─ ui-helpers.js         # DOM manipulation helpers
 ├─ /styles                   # CSS files
 │   ├─ tokens.css            # Design system variables
 │   ├─ reset.css             # CSS reset/normalize
 │   ├─ layout.css            # Layout utilities
 │   ├─ components.css        # Component styles
 │   └─ utilities.css         # Utility classes
 ├─ /data                     # Static JSON data
 │   ├─ core.json
 │   └─ config.json
 ├─ /assets                   # Static assets
 │   ├─ /images
 │   └─ /icons
 └─ /docs                     # Documentation
     ├─ usage.md
     ├─ localization.md
     └─ automation.md
```
</structure>

## Working with HTML

<conventions>
When creating or modifying HTML, follow these patterns:

### Semantic Markup

**Always use semantic HTML5 elements.** They provide meaning, improve SEO, and enhance accessibility.

**Example: Semantic Structure**
```html
<!-- ✅ Good: Semantic elements -->
<header class="site-header">
  <nav aria-label="Main navigation">
    <ul class="nav-list">
      <li><a href="/">Home</a></li>
      <li><a href="/about">About</a></li>
    </ul>
  </nav>
</header>

<main>
  <article class="post">
    <header>
      <h1>Article Title</h1>
      <time datetime="2024-01-15">January 15, 2024</time>
    </header>
    <section>
      <p>Article content...</p>
    </section>
  </article>
</main>

<footer class="site-footer">
  <p>&copy; 2024 Company Name</p>
</footer>

<!-- ❌ Bad: Generic divs everywhere -->
<div class="header">
  <div class="nav">
    <!-- Navigation -->
  </div>
</div>
<div class="main">
  <div class="post">
    <!-- Content -->
  </div>
</div>
```

### Template Fragments

**Create reusable HTML patterns** using template fragments for common UI components.

**Example: Card Template**
```html
<!-- templates/card.html -->
<article class="card" data-component="card">
  <header class="card__header">
    <h3 class="card__title"><!-- Title --></h3>
  </header>
  <div class="card__body">
    <p class="card__description"><!-- Description --></p>
  </div>
  <footer class="card__footer">
    <a href="#" class="card__link">Learn more</a>
  </footer>
</article>
```

Then use JavaScript to instantiate:

```javascript
// scripts/ui-helpers.js
export async function loadTemplate(name) {
  const response = await fetch(`/templates/${name}.html`);
  return await response.text();
}

export function renderCard(data) {
  const card = document.createElement('article');
  card.className = 'card';
  card.innerHTML = `
    <header class="card__header">
      <h3 class="card__title">${data.title}</h3>
    </header>
    <div class="card__body">
      <p class="card__description">${data.description}</p>
    </div>
    <footer class="card__footer">
      <a href="${data.link}" class="card__link">Learn more</a>
    </footer>
  `;
  return card;
}
```

### Accessibility Requirements

**Every page must be fully accessible** without requiring JavaScript.

**Checklist:**
- ✅ All images have descriptive `alt` attributes
- ✅ Form inputs have associated `<label>` elements
- ✅ Interactive elements are keyboard accessible
- ✅ Focus indicators are visible and clear
- ✅ Heading hierarchy is logical (h1 → h2 → h3)
- ✅ ARIA labels used where semantic HTML isn't sufficient
- ✅ Color contrast meets WCAG AA standards (minimum 4.5:1)

**Example: Accessible Form**
```html
<form class="contact-form" action="/submit" method="post">
  <div class="form-group">
    <label for="name">Name</label>
    <input
      type="text"
      id="name"
      name="name"
      required
      aria-required="true"
      autocomplete="name"
    />
  </div>

  <div class="form-group">
    <label for="email">Email</label>
    <input
      type="email"
      id="email"
      name="email"
      required
      aria-required="true"
      aria-describedby="email-hint"
      autocomplete="email"
    />
    <span id="email-hint" class="form-hint">
      We'll never share your email
    </span>
  </div>

  <button type="submit" class="btn btn--primary">
    Send Message
  </button>
</form>
```

### Meta Tags and SEO

**Include comprehensive meta tags** in the `<head>` section.

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Concise page description (150-160 chars)">
  <meta name="keywords" content="relevant, keywords, here">

  <!-- Open Graph -->
  <meta property="og:title" content="Page Title">
  <meta property="og:description" content="Page description">
  <meta property="og:image" content="https://example.com/og-image.jpg">
  <meta property="og:url" content="https://example.com/page">
  <meta property="og:type" content="website">

  <!-- Twitter Card -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="Page Title">
  <meta name="twitter:description" content="Page description">
  <meta name="twitter:image" content="https://example.com/twitter-image.jpg">

  <title>Page Title | Site Name</title>
  <link rel="canonical" href="https://example.com/page">
  <link rel="stylesheet" href="/styles/tokens.css">
  <link rel="stylesheet" href="/styles/reset.css">
  <link rel="stylesheet" href="/styles/layout.css">
</head>
```
</conventions>

## Working with CSS

<css-conventions>
### Token-First Design

**Never hardcode visual values.** All colors, spacing, typography must use CSS variables from `tokens.css`.

**Example: Design Token System**
```css
/* styles/tokens.css */
:root {
  /* Colors - OKLCH format */
  --color-primary: oklch(0.5 0.2 220);
  --color-surface: oklch(0.95 0.01 220);
  --color-text: oklch(0.2 0.01 220);
  --color-text-muted: oklch(0.5 0.01 220);
  --color-border: oklch(0.85 0.01 220);
  --color-success: oklch(0.6 0.15 145);
  --color-error: oklch(0.6 0.2 25);

  /* Spacing - 4px base scale */
  --spacing-xs: 4px;
  --spacing-sm: 8px;
  --spacing-md: 16px;
  --spacing-lg: 24px;
  --spacing-xl: 32px;
  --spacing-2xl: 48px;
  --spacing-3xl: 64px;

  /* Typography */
  --font-family-base: Inter, system-ui, sans-serif;
  --font-family-mono: "JetBrains Mono", Consolas, monospace;
  --font-size-xs: 12px;
  --font-size-sm: 14px;
  --font-size-base: 16px;
  --font-size-lg: 18px;
  --font-size-xl: 24px;
  --font-size-2xl: 32px;
  --line-height-tight: 1.25;
  --line-height-base: 1.5;
  --line-height-relaxed: 1.75;

  /* Layout */
  --max-width-content: 1440px;
  --max-width-text: 65ch;
}
```

**Using Tokens:**
```css
/* ✅ Good: Using design tokens */
.card {
  background: var(--color-surface);
  color: var(--color-text);
  padding: var(--spacing-lg);
  border: 1px solid var(--color-border);
  border-radius: var(--spacing-xs);
  font-family: var(--font-family-base);
}

/* ❌ Bad: Hardcoded values */
.card-bad {
  background: #f5f5f5;
  color: #333;
  padding: 24px;
  border: 1px solid #ddd;
  font-family: Arial, sans-serif;
}
```

### Layout Patterns

**No flex-wrap allowed.** Use horizontal scroll or text truncation for overflow.

```css
/* ✅ Good: Horizontal scroll container */
.card-grid {
  display: flex;
  gap: var(--spacing-md);
  overflow-x: auto;
  scroll-behavior: smooth;
  scroll-snap-type: x mandatory;
}

.card {
  flex: 0 0 300px;
  scroll-snap-align: start;
}

/* ❌ Bad: Wrapping layout */
.card-grid-bad {
  display: flex;
  flex-wrap: wrap; /* Never use this */
}

/* ✅ Good: Truncate overflowing text */
.card-title {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
```

### Mobile-First Responsive Design

**Start with mobile styles, add complexity upward.**

```css
/* Base styles (mobile) */
.container {
  padding: var(--spacing-md);
}

.grid {
  display: grid;
  gap: var(--spacing-md);
}

/* Tablet (768px+) */
@media (min-width: 768px) {
  .container {
    padding: var(--spacing-lg);
  }

  .grid {
    grid-template-columns: repeat(2, 1fr);
  }
}

/* Desktop (1024px+) */
@media (min-width: 1024px) {
  .container {
    padding: var(--spacing-xl);
    max-width: var(--max-width-content);
    margin-inline: auto;
  }

  .grid {
    grid-template-columns: repeat(3, 1fr);
  }
}
```

### Image Optimization

**Use modern image formats with fallbacks.**

```html
<!-- ✅ Good: Modern formats with fallback -->
<picture>
  <source srcset="/hero.avif" type="image/avif">
  <source srcset="/hero.webp" type="image/webp">
  <img
    src="/hero.jpg"
    alt="Detailed description of image content"
    width="1200"
    height="600"
    loading="lazy"
  >
</picture>

<!-- ❌ Bad: Old format, no dimensions -->
<img src="/hero.png" alt="hero">
```
</css-conventions>

## Working with JavaScript

<js-conventions>
### ES Modules

**Use modern JavaScript modules** for clean code organization.

**Example: Module Structure**
```javascript
// scripts/app.js (main entry point)
import { renderCard } from './ui-helpers.js';
import { filterData } from './filters.js';

async function init() {
  const data = await fetch('/data/core.json').then(r => r.json());
  const container = document.getElementById('card-container');

  data.forEach(item => {
    const card = renderCard(item);
    container.appendChild(card);
  });
}

// Run when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
```

```javascript
// scripts/ui-helpers.js
export function renderCard(data) {
  const card = document.createElement('article');
  card.className = 'card';
  card.innerHTML = `
    <h3 class="card__title">${escapeHtml(data.title)}</h3>
    <p class="card__description">${escapeHtml(data.description)}</p>
  `;
  return card;
}

export function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}
```

### Event Handling

**Use event delegation** for better performance with dynamic content.

```javascript
// ✅ Good: Event delegation
document.addEventListener('click', (event) => {
  if (event.target.matches('.card__link')) {
    event.preventDefault();
    handleCardClick(event.target.closest('.card'));
  }
});

// ❌ Bad: Individual listeners
document.querySelectorAll('.card__link').forEach(link => {
  link.addEventListener('click', handleCardClick);
});
```

### Web APIs Over Libraries

**Prefer native Web APIs** when possible.

```javascript
// ✅ Good: Native Fetch API
async function fetchData(url) {
  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return await response.json();
  } catch (error) {
    console.error('Fetch failed:', error);
    return null;
  }
}

// ✅ Good: Native IntersectionObserver for lazy loading
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const img = entry.target;
      img.src = img.dataset.src;
      observer.unobserve(img);
    }
  });
});

document.querySelectorAll('img[data-src]').forEach(img => {
  observer.observe(img);
});
```
</js-conventions>

## Development Workflow

<development>
### Starting a Local Server

**Python:**
```bash
python -m http.server 8080
```

**Node.js:**
```bash
npx http-server -p 8080 -c-1
```

**With Live Reload:**
```bash
npx browser-sync start --server --files "**/*" --no-notify
```

The site will be available at `http://localhost:8080`

### When Making Changes

1. **Modify files directly** — No build step required
2. **Refresh browser** — Changes are immediately visible
3. **Test across devices** — Use browser dev tools device emulation
4. **Validate HTML/CSS** — Run validation tools regularly
5. **Test without JavaScript** — Ensure core functionality works
</development>

## Code Quality & Validation

<validation>
Validation commands for code quality:

```bash
# HTML validation
npx html-validate "**/*.html"

# CSS validation and auto-fix
npx stylelint "**/*.css" --fix

# JavaScript linting
npx eslint "**/*.js" --fix

# Performance & accessibility audit
npx lighthouse http://localhost:8080 --view

# Accessibility testing
npx axe-cli http://localhost:8080
```

**Quality Gates:**
- HTML validation passes with no errors
- CSS has no linting issues
- JavaScript follows consistent style
- Lighthouse scores ≥ 90 for Performance, Accessibility, SEO
- No console errors or warnings
</validation>

## Making Edits

<guidance>
When I work on this codebase, I will:

### Preserve Separation of Concerns

- **Keep HTML, CSS, and JS separate** — No inline styles or scripts except critical CSS
- **Extend tokens.css** — Add new design tokens rather than hardcoding values
- **Maintain consistent naming** — Follow existing BEM or naming patterns
- **Comment complex logic** — Explain DOM manipulation or event handling

### Adding Features

When adding new functionality:

1. **Check if JavaScript is necessary** — Can it be done with CSS?
2. **Progressive enhancement** — Start with HTML/CSS, enhance with JS
3. **Test without JavaScript** — Core content must be accessible
4. **Use native Web APIs** — Avoid adding libraries unless absolutely necessary
5. **Keep dependencies minimal** — Prefer CDN links over package managers

### Example: Adding a Modal

```javascript
// scripts/modal.js
export function createModal(title, content) {
  const modal = document.createElement('div');
  modal.className = 'modal';
  modal.setAttribute('role', 'dialog');
  modal.setAttribute('aria-modal', 'true');
  modal.setAttribute('aria-labelledby', 'modal-title');

  modal.innerHTML = `
    <div class="modal__overlay"></div>
    <div class="modal__content">
      <header class="modal__header">
        <h2 id="modal-title">${title}</h2>
        <button
          class="modal__close"
          aria-label="Close modal"
        >&times;</button>
      </header>
      <div class="modal__body">${content}</div>
    </div>
  `;

  // Close on overlay click
  modal.querySelector('.modal__overlay').addEventListener('click', () => {
    closeModal(modal);
  });

  // Close on button click
  modal.querySelector('.modal__close').addEventListener('click', () => {
    closeModal(modal);
  });

  // Close on Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && document.body.contains(modal)) {
      closeModal(modal);
    }
  });

  return modal;
}

function closeModal(modal) {
  modal.remove();
  // Restore focus to trigger element if needed
}
```
</guidance>

## Deployment

<deployment>
### Deployment Steps

No build step required! Deploy the files as-is.

```bash
# Just upload the entire frontend-static directory
```

### Deployment Checklist

✅ All file paths are relative or absolute (no broken links)
✅ Meta tags and Open Graph tags configured
✅ Favicon and manifest.json present
✅ Images optimized (AVIF/WebP with fallbacks)
✅ Cache headers configured for static assets
✅ Gzip/Brotli compression enabled at server level
✅ Lighthouse audit scores ≥ 90

### Coolify Static Build Pack

- **Build Command:** None (static files)
- **Output Directory:** `.` (root)
- **Cache Strategy:**
  - `/assets/*` → 1 year
  - `/styles/*` → 1 year
  - `/scripts/*` → 1 year
  - `*.html` → No cache or short TTL
</deployment>

## Version Control

<git>
### Branch Strategy

- `main` — Production-ready code
- `feature/*` — New features
- `fix/*` — Bug fixes
- `docs/*` — Documentation updates

### Commit Conventions

**Good commits:**
- `Add modal component with keyboard navigation`
- `Fix focus trap in navigation menu`
- `Update tokens.css with new spacing scale`
- `Optimize images using AVIF format`

**Before merging:**
- ✅ HTML validation passes
- ✅ CSS linting passes
- ✅ Accessibility audit passes
- ✅ Performance metrics meet thresholds
</git>

## Design Philosophy

<philosophy>
**Lightweight, structured, and timeless.**

This project will work without modification for years. No dependency updates, no build tool migrations, no framework rewrites.

**OKLCH-driven design, zero build complexity, and fully modular HTML.**

The OKLCH color model ensures perceptual uniformity — all colors with the same lightness value appear equally bright, creating natural visual harmony.

**Simple by default, beautiful by design, production-ready always.**

By avoiding build complexity, we gain:
- Instant deployment
- No dependency vulnerabilities
- Debuggable code (what you write is what runs)
- Longevity (works indefinitely)
</philosophy>

---

**When in doubt, favor simplicity.** If a feature can be accomplished with HTML and CSS, don't reach for JavaScript. Progressive enhancement means the core experience works everywhere, and JavaScript adds polish.
