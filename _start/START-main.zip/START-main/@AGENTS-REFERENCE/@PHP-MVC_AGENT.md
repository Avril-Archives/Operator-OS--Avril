# AGENTS.md — PHP MVC Backend

## Purpose

Defines clean, modern standards for Laravel/Symfony-style MVC applications with OKLCH tokens and semantic templates.

**Goal:** structured, maintainable PHP with modern standards and token-driven UI.

## Stack & Conventions

- PHP ≥ 8.2 with strict types
- PSR-12 coding standard, PSR-4 autoloading
- Laravel or Symfony framework
- Blade/Twig templates using OKLCH tokens from `/shared/tokens.json`
- Database: Eloquent or Doctrine ORM
- Testing: PHPUnit or Pest
- No flex-wrap in CSS; semantic HTML5
- UTF-8 encoding, LF endings, 4-space indent

## Structure

```
/app (Controllers, Models, Services)
/config (app.php, database.php, cache.php)
/database (migrations, seeders)
/public (index.php, assets)
/resources
 ├─ /views (Blade/Twig templates)
 ├─ /css (tokens.css from /shared)
/routes (web.php, api.php)
/tests
/docs
```

## Authoring Rules

- Controllers thin; delegate business logic to Service layer
- Validation via FormRequest or dedicated Validator classes
- Use CSS variables from `tokens.css`; never hardcode colors
- Templates must be semantic HTML with ARIA where needed
- Add `/health` route returning `{ "status": "ok", "timestamp": ISO8601 }`
- Return proper HTTP status codes with structured JSON for APIs
- Enable OPcache and config caching in production

## Agent Behavior

- Scoped edits only; preserve routing and middleware conventions
- Respect existing naming patterns for controllers and models
- Justify new packages; prefer framework-native solutions
- Keep Blade/Twig templates accessible and semantic
- Update tests and docs with every route or model change
- Comment intent behind complex queries or business rules

## Development

```bash
composer install
php artisan serve
```

Runs on `http://localhost:8000`.

Database migrations:

```bash
php artisan migrate
php artisan db:seed
```

## Validation

```bash
composer lint         # PHP_CodeSniffer (PSR-12)
composer format       # PHP-CS-Fixer
composer test         # PHPUnit/Pest
php artisan test      # Laravel feature tests
```

## Deployment

Build and optimize:

```bash
composer install --no-dev --optimize-autoloader
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

Coolify: Use Dockerfile with PHP-FPM + Nginx.

Web root: `/public`

Required:

- `/health` endpoint for healthcheck
- Environment variables via `.env`
- Enable OPcache and config caching
- Configure CORS for API routes

## Version Control

- **Branches:** main / feature/* / fix/* / docs/*
- **Commits:** imperative, one logical change per commit
- Include security audit and test validation before PR merge

## Philosophy

Structured, semantic, and token-driven.

**Service-layer logic, template-based UI, production-ready always.**

Clean by design, maintainable through patterns, scalable through structure.