# Agent Rules Collection

A comprehensive set of AI coding agent configuration files for modern full-stack development with OKLCH-driven design systems.

## Overview

This collection provides specialized AGENTS.md files for different project types, all adhering to a unified design philosophy:

- **Mobile-first design** with responsive layouts (320–1440px)
- **OKLCH color model** for perceptual color harmony
- **Monochrome palette** with purposeful color signals
- **4px base spacing scale** for consistent vertical rhythm
- **Token-driven design** from `/shared/tokens.json`
- **No flex-wrap** — use scroll, truncation, or overflow
- **Semantic HTML** with mandatory accessibility

## Available Configurations

### Frontend

**[Static-AGENTS.md](./Static-AGENTS.md)**  
Zero-build static HTML/CSS/JS projects with vanilla JavaScript and token-driven CSS.

**[ReactVite-AGENTS.md](./ReactVite-AGENTS.md)**  
React 18+ with Vite bundler, component-driven architecture, and modern hooks patterns.

### Backend

**[NodeJS-AGENTS.md](./NodeJS-AGENTS.md)**  
Node.js REST APIs with Express/Fastify, TypeScript, Zod validation, and Drizzle ORM.

**[FastAPI-AGENTS.md](./FastAPI-AGENTS.md)**  
Python FastAPI microservices with async patterns, Pydantic models, and auto-generated docs.

**[PHP-AGENTS.md](./PHP-AGENTS.md)**  
Laravel/Symfony MVC applications with Blade/Twig templates and Eloquent/Doctrine ORM.

### Full-Stack

**[FullStack-AGENTS.md](./FullStack-AGENTS.md)**  
Integrated frontend and backend projects with shared design tokens and unified architecture.

## Quick Start

1. **Choose your project type** from the configurations above
1. **Copy the appropriate AGENTS.md** to your project root
1. **Create `/shared/tokens.json`** with your design tokens:

```json
{
  "colors": {
    "primary": "oklch(0.5 0.2 220)",
    "surface": "oklch(0.95 0.01 220)",
    "text": "oklch(0.2 0.01 220)"
  },
  "spacing": {
    "xs": "4px",
    "sm": "8px",
    "md": "16px",
    "lg": "24px",
    "xl": "32px"
  },
  "typography": {
    "font-family-base": "Inter, system-ui, sans-serif",
    "font-family-mono": "JetBrains Mono, monospace",
    "font-size-base": "16px",
    "line-height-base": "1.5"
  }
}
```

1. **Reference tokens in CSS:**

```css
:root {
  --color-primary: oklch(0.5 0.2 220);
  --spacing-md: 16px;
  --font-family-base: Inter, system-ui, sans-serif;
}
```

1. **Let AI assistants discover your configuration** automatically

## Design Philosophy

### Core Principles

**Purposeful Minimalism** — Eliminate all non-essential elements  
**Monochrome Discipline** — Maintain visual clarity with grayscale base  
**Spatial Hierarchy** — Use spacing and layout to guide attention  
**Subtle Sophistication** — Refined, restrained interactions  
**Functional Beauty** — Elevate both form and function  
**Consistent Rhythm** — Predictable visual cadence across viewports

### Technical Standards

- **24-column fluid grid** for responsive layouts
- **Mathematical spacing scale** (4px base)
- **OKLCH color model** for perceptual uniformity
- **Flexbox layouts** with intentional scroll patterns
- **Progressive disclosure** for layered complexity
- **Strategic whitespace** for structure and contrast

## File Organization

```
/project
 ├─ AGENTS.md (project-specific configuration)
 ├─ /frontend (React/Vite or static)
 ├─ /backend (Node/FastAPI/PHP)
 ├─ /shared
 │   ├─ tokens.json (design system)
 │   ├─ types (TypeScript interfaces)
 │   └─ constants (shared config)
 ├─ /docs (architecture, deployment)
 └─ /scripts (automation, utilities)
```

## Usage with AI Assistants

These AGENTS.md files work with:

- **Claude Code** (hierarchical `.claude/CLAUDE.md` system)
- **Cursor IDE** (`.cursor/rules/*.mdc` format)
- **GitHub Copilot** (`.github/copilot-instructions.md`)
- **OpenAI Codex** (automatic discovery)
- **Windsurf, Zed, Aider** (universal support)

Place AGENTS.md at your project root for automatic discovery by most AI coding assistants.

## Best Practices

### Configuration Maintenance

✅ **Review on every architectural change**  
✅ **Keep examples current and realistic**  
✅ **Link to detailed docs instead of duplicating**  
✅ **Use nested files for monorepo scoping**  
✅ **Treat as living documentation**

### Anti-Patterns to Avoid

❌ Vague instructions (“write good code”)  
❌ Outdated examples or deprecated patterns  
❌ Excessive duplication across files  
❌ Missing reasoning behind rules  
❌ Overly broad scope without globs/hierarchy

## Migration Strategy

### From Tool-Specific to Universal

1. **Audit** existing config files (`.cursor/rules`, `CLAUDE.md`, etc.)
1. **Consolidate** common patterns into AGENTS.md
1. **Maintain both** for transition period
1. **Deprecate gradually** as tools adopt universal standard

### Symlink Strategy (Interim)

```bash
# Create AGENTS.md as source of truth
touch AGENTS.md

# Symlink tool-specific files
ln -s AGENTS.md .cursor/rules/project.mdc
ln -s AGENTS.md .claude/CLAUDE.md
ln -s AGENTS.md .github/copilot-instructions.md
```

## Validation

Each AGENTS.md file includes validation commands:

```bash
# Frontend
npm run lint && npm run test && npm run build

# Backend
npm run lint && npm run test  # Node
pytest && ruff check .        # Python
composer test && composer lint # PHP

# Accessibility & Performance
npx lighthouse http://localhost:8080 --view
```

## Contributing

Contributions welcome! Please:

1. Follow existing structure and tone
1. Keep files under 100 lines
1. Test with actual AI assistants
1. Include validation commands
1. Document reasoning behind rules

## Resources

**Official Standards:**

- [AGENTS.md Standard](https://github.com/openai/agents.md)
- [Claude Code Documentation](https://docs.claude.com/en/docs/claude-code)
- [Cursor Rules Guide](https://cursor.com/docs/context/rules)

**Design Systems:**

- [OKLCH Color Picker](https://oklch.com)
- [Inter Font](https://rsms.me/inter/)
- [JetBrains Mono](https://www.jetbrains.com/lp/mono/)
- [Phosphor Icons](https://phosphoricons.com)

## License

MIT — Use freely for personal or commercial projects.

-----

**Philosophy:** READMEs are for humans; AGENTS.md is for machines.

Start with tokens, design with intention, validate relentlessly.