#!/bin/bash

###############################################################################
# Cloud Storage Management Script
#
# A reusable script for managing files on Cardsite Cloud Storage API.
# Designed to be LLM-friendly with clear structure and comprehensive comments.
#
# Setup:
#   1. Copy this script to any repository
#   2. chmod +x cloud-storage.sh
#   3. Set CLOUD_STORAGE_TOKEN environment variable
#   4. Run ./cloud-storage.sh --help for usage
#
# Environment Variables:
#   CLOUD_STORAGE_TOKEN - Your API access token (required)
#   CLOUD_STORAGE_API   - API base URL (default: https://cloud.card.tools/api/v1)
#
# Usage:
#   ./cloud-storage.sh upload <file> [parent_id]
#   ./cloud-storage.sh list [parent_id]
#   ./cloud-storage.sh folder <name> [parent_id]
#   ./cloud-storage.sh delete <entry_id> [permanent]
#   ./cloud-storage.sh move <entry_id> <destination_id>
#   ./cloud-storage.sh rename <entry_id> <new_name>
#   ./cloud-storage.sh share <entry_id>
#   ./cloud-storage.sh search <query>
#
###############################################################################

set -e  # Exit on error

# Configuration
API_BASE="${CLOUD_STORAGE_API:-https://cloud.card.tools/api/v1}"
TOKEN="${CLOUD_STORAGE_TOKEN}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

###############################################################################
# Helper Functions
###############################################################################

# Print colored message
print_error() {
    echo -e "${RED}ERROR: $1${NC}" >&2
}

print_success() {
    echo -e "${GREEN}SUCCESS: $1${NC}"
}

print_info() {
    echo -e "${BLUE}INFO: $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}WARNING: $1${NC}"
}

# Check if token is set
check_token() {
    if [ -z "$TOKEN" ]; then
        print_error "CLOUD_STORAGE_TOKEN environment variable is not set"
        echo ""
        echo "Get your token from: https://cloud.card.tools/account-settings"
        echo ""
        echo "Then set it:"
        echo "  export CLOUD_STORAGE_TOKEN='your_token_here'"
        echo ""
        echo "Or create a .env file:"
        echo "  echo 'CLOUD_STORAGE_TOKEN=your_token_here' > .env"
        echo "  source .env"
        exit 1
    fi
}

# Make API request
api_request() {
    local method="$1"
    local endpoint="$2"
    local data="$3"

    if [ -z "$data" ]; then
        curl -s -X "$method" "${API_BASE}${endpoint}" \
            -H "Authorization: Bearer ${TOKEN}" \
            -H "Accept: application/json"
    else
        curl -s -X "$method" "${API_BASE}${endpoint}" \
            -H "Authorization: Bearer ${TOKEN}" \
            -H "Accept: application/json" \
            -H "Content-Type: application/json" \
            -d "$data"
    fi
}

# Pretty print JSON response
pretty_json() {
    if command -v jq &> /dev/null; then
        echo "$1" | jq '.'
    else
        echo "$1"
    fi
}

###############################################################################
# Core Functions
###############################################################################

# Upload a file
upload_file() {
    local file_path="$1"
    local parent_id="${2:-null}"

    if [ ! -f "$file_path" ]; then
        print_error "File not found: $file_path"
        exit 1
    fi

    print_info "Uploading $(basename "$file_path")..."

    local response=$(curl -s -X POST "${API_BASE}/uploads" \
        -H "Authorization: Bearer ${TOKEN}" \
        -H "Accept: application/json" \
        -F "file=@${file_path}" \
        -F "parentId=${parent_id}" \
        -F "uploadType=bedrive")

    if echo "$response" | grep -q '"status":"success"'; then
        local file_id=$(echo "$response" | grep -o '"id":[0-9]*' | head -1 | cut -d':' -f2)
        local file_size=$(echo "$response" | grep -o '"file_size":[0-9]*' | head -1 | cut -d':' -f2)
        print_success "File uploaded successfully"
        echo "  File ID: $file_id"
        echo "  Size: $file_size bytes"
    else
        print_error "Upload failed"
        pretty_json "$response"
        exit 1
    fi
}

# List files and folders
list_entries() {
    local parent_id="$1"
    local query_params=""

    if [ -n "$parent_id" ]; then
        query_params="?parentIds=${parent_id}"
    fi

    print_info "Fetching file list..."

    local response=$(api_request "GET" "/drive/file-entries${query_params}")

    if echo "$response" | grep -q '"current_page"'; then
        echo ""
        echo "Files and Folders:"
        echo "===================="

        if command -v jq &> /dev/null; then
            echo "$response" | jq -r '.data[] | "[\(.type)] \(.name) (ID: \(.id), Size: \(.file_size) bytes)"'
        else
            pretty_json "$response"
        fi
    else
        print_error "Failed to fetch files"
        pretty_json "$response"
        exit 1
    fi
}

# Create a folder
create_folder() {
    local folder_name="$1"
    local parent_id="${2:-null}"

    if [ -z "$folder_name" ]; then
        print_error "Folder name is required"
        exit 1
    fi

    print_info "Creating folder: $folder_name..."

    local data="{\"name\":\"${folder_name}\",\"parentId\":${parent_id}}"
    local response=$(api_request "POST" "/folders" "$data")

    if echo "$response" | grep -q '"status":"success"'; then
        local folder_id=$(echo "$response" | grep -o '"id":[0-9]*' | head -1 | cut -d':' -f2)
        print_success "Folder created successfully"
        echo "  Folder ID: $folder_id"
        echo "  Name: $folder_name"
    else
        print_error "Failed to create folder"
        pretty_json "$response"
        exit 1
    fi
}

# Delete file or folder
delete_entry() {
    local entry_id="$1"
    local permanent="${2:-false}"

    if [ -z "$entry_id" ]; then
        print_error "Entry ID is required"
        exit 1
    fi

    if [ "$permanent" = "true" ] || [ "$permanent" = "1" ]; then
        print_warning "Permanently deleting entry $entry_id..."
        local delete_forever="true"
    else
        print_info "Moving entry $entry_id to trash..."
        local delete_forever="false"
    fi

    local data="{\"entryIds\":[\"${entry_id}\"],\"deleteForever\":${delete_forever}}"
    local response=$(api_request "POST" "/file-entries/delete" "$data")

    if echo "$response" | grep -q '"status":"success"'; then
        print_success "Entry deleted successfully"
    else
        print_error "Failed to delete entry"
        pretty_json "$response"
        exit 1
    fi
}

# Move file or folder
move_entry() {
    local entry_id="$1"
    local destination_id="${2:-null}"

    if [ -z "$entry_id" ]; then
        print_error "Entry ID is required"
        exit 1
    fi

    print_info "Moving entry $entry_id to folder $destination_id..."

    local data="{\"entryIds\":[${entry_id}],\"destinationId\":${destination_id}}"
    local response=$(api_request "POST" "/file-entries/move" "$data")

    if echo "$response" | grep -q '"status":"success"'; then
        print_success "Entry moved successfully"
    else
        print_error "Failed to move entry"
        pretty_json "$response"
        exit 1
    fi
}

# Rename file or folder
rename_entry() {
    local entry_id="$1"
    local new_name="$2"

    if [ -z "$entry_id" ] || [ -z "$new_name" ]; then
        print_error "Entry ID and new name are required"
        exit 1
    fi

    print_info "Renaming entry $entry_id to $new_name..."

    local data="{\"name\":\"${new_name}\"}"
    local response=$(api_request "PUT" "/file-entries/${entry_id}" "$data")

    if echo "$response" | grep -q '"status":"success"'; then
        print_success "Entry renamed successfully"
    else
        print_error "Failed to rename entry"
        pretty_json "$response"
        exit 1
    fi
}

# Create shareable link
create_share_link() {
    local entry_id="$1"
    local allow_download="${2:-true}"

    if [ -z "$entry_id" ]; then
        print_error "Entry ID is required"
        exit 1
    fi

    print_info "Creating shareable link for entry $entry_id..."

    local data="{\"allow_download\":${allow_download}}"
    local response=$(api_request "POST" "/file-entries/${entry_id}/shareable-link" "$data")

    if echo "$response" | grep -q '"status":"success"'; then
        print_success "Shareable link created"
        if command -v jq &> /dev/null; then
            local hash=$(echo "$response" | jq -r '.link.hash')
            echo "  Link: https://cloud.card.tools/drive/shares/${hash}"
        else
            pretty_json "$response"
        fi
    else
        print_error "Failed to create shareable link"
        pretty_json "$response"
        exit 1
    fi
}

# Search files
search_files() {
    local query="$1"

    if [ -z "$query" ]; then
        print_error "Search query is required"
        exit 1
    fi

    print_info "Searching for: $query..."

    local response=$(api_request "GET" "/drive/file-entries?query=${query}")

    if echo "$response" | grep -q '"current_page"'; then
        echo ""
        echo "Search Results:"
        echo "==============="

        if command -v jq &> /dev/null; then
            local count=$(echo "$response" | jq '.data | length')
            echo "Found $count result(s)"
            echo ""
            echo "$response" | jq -r '.data[] | "[\(.type)] \(.name) (ID: \(.id), Size: \(.file_size) bytes)"'
        else
            pretty_json "$response"
        fi
    else
        print_error "Search failed"
        pretty_json "$response"
        exit 1
    fi
}

# Upload entire directory recursively
upload_directory() {
    local dir_path="$1"
    local parent_id="${2:-null}"

    if [ ! -d "$dir_path" ]; then
        print_error "Directory not found: $dir_path"
        exit 1
    fi

    local dir_name=$(basename "$dir_path")

    # Create folder for directory
    print_info "Creating folder for directory: $dir_name"
    local folder_data="{\"name\":\"${dir_name}\",\"parentId\":${parent_id}}"
    local folder_response=$(api_request "POST" "/folders" "$folder_data")
    local new_folder_id=$(echo "$folder_response" | grep -o '"id":[0-9]*' | head -1 | cut -d':' -f2)

    if [ -z "$new_folder_id" ]; then
        print_error "Failed to create folder for directory"
        exit 1
    fi

    print_success "Created folder (ID: $new_folder_id)"

    # Upload all files in directory
    find "$dir_path" -maxdepth 1 -type f | while read -r file; do
        upload_file "$file" "$new_folder_id"
    done

    # Recursively upload subdirectories
    find "$dir_path" -maxdepth 1 -type d ! -path "$dir_path" | while read -r subdir; do
        upload_directory "$subdir" "$new_folder_id"
    done
}

###############################################################################
# Command Dispatcher
###############################################################################

show_help() {
    cat << EOF
Cloud Storage Management Script
================================

Usage:
  $0 <command> [options]

Commands:
  upload <file> [parent_id]           Upload a file
  upload-dir <directory> [parent_id]  Upload entire directory recursively
  list [parent_id]                    List files and folders
  folder <name> [parent_id]           Create a folder
  delete <entry_id> [permanent]       Delete file/folder (permanent: true/false)
  move <entry_id> <destination_id>    Move file/folder
  rename <entry_id> <new_name>        Rename file/folder
  share <entry_id>                    Create shareable link
  search <query>                      Search for files
  help                                Show this help message

Examples:
  $0 upload document.pdf
  $0 upload document.pdf 21
  $0 upload-dir ./my-docs
  $0 list
  $0 list 21
  $0 folder "My Documents"
  $0 folder "Work Files" 21
  $0 delete 25
  $0 delete 25 true
  $0 move 25 21
  $0 rename 25 "new-name.pdf"
  $0 share 25
  $0 search "report"

Environment Variables:
  CLOUD_STORAGE_TOKEN  - Your API access token (required)
  CLOUD_STORAGE_API    - API base URL (optional)

Setup:
  1. Get token from: https://cloud.card.tools/account-settings
  2. export CLOUD_STORAGE_TOKEN='your_token_here'
  3. Run commands as shown above

For full documentation, see: cloud-upload-guide.md
EOF
}

# Main entry point
main() {
    local command="${1:-help}"

    case "$command" in
        upload)
            check_token
            upload_file "$2" "$3"
            ;;
        upload-dir)
            check_token
            upload_directory "$2" "$3"
            ;;
        list)
            check_token
            list_entries "$2"
            ;;
        folder)
            check_token
            create_folder "$2" "$3"
            ;;
        delete)
            check_token
            delete_entry "$2" "$3"
            ;;
        move)
            check_token
            move_entry "$2" "$3"
            ;;
        rename)
            check_token
            rename_entry "$2" "$3"
            ;;
        share)
            check_token
            create_share_link "$2"
            ;;
        search)
            check_token
            search_files "$2"
            ;;
        help|--help|-h)
            show_help
            ;;
        *)
            print_error "Unknown command: $command"
            echo ""
            show_help
            exit 1
            ;;
    esac
}

# Run main function
main "$@"
